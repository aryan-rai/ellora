import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { Search, MapPin, Phone, Star, Filter } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Fix for default markers in react-leaflet
delete (L.Icon.Default.prototype as any)._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon-2x.png',
  iconUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-icon.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
});

interface Doctor {
  id: string;
  name: string;
  specialty: string;
  phone: string;
  rating: number;
  address: string;
  lat: number;
  lng: number;
  distance: string;
}

const mockDoctors: Doctor[] = [
  {
    id: '1',
    name: 'Dr. Mitali Upadhye',
    specialty: 'Cardiologist',
    phone: '+911234567890',
    rating: 4.8,
    address: '123 Medical Center Dr',
    lat: 18.512222018221323,
    lng: 73.80358303112699,
    distance: '0.5 mi'
  },
  {
    id: '2',
    name: 'Dr. Michael Chen',
    specialty: 'General Practitioner',
    phone: '+1 (555) 234-5678',
    rating: 4.6,
    address: '456 Health Plaza',
    lat: 40.7589,
    lng: -73.9851,
    distance: '1.2 mi'
  },
  {
    id: '3',
    name: 'Dr. Emily Davis',
    specialty: 'Dentist',
    phone: '+1 (555) 345-6789',
    rating: 4.9,
    address: '789 Dental Ave',
    lat: 40.7413,
    lng: -74.0011,
    distance: '0.8 mi'
  },
  {
    id: '4',
    name: 'Dr. Robert Wilson',
    specialty: 'Dermatologist',
    phone: '+1 (555) 456-7890',
    rating: 4.7,
    address: '321 Skin Care Blvd',
    lat: 40.7505,
    lng: -73.9934,
    distance: '1.5 mi'
  }
];

const specialties = [
  'All Specialties',
  'General Practitioner',
  'Cardiologist',
  'Dentist',
  'Dermatologist',
  'Pediatrician',
  'Psychiatrist',
  'Orthopedist'
];

const DoctorsPage: React.FC = () => {
  const [doctors, setDoctors] = useState<Doctor[]>(mockDoctors);
  const [filteredDoctors, setFilteredDoctors] = useState<Doctor[]>(mockDoctors);
  const [searchLocation, setSearchLocation] = useState('New York, NY');
  const [selectedSpecialty, setSelectedSpecialty] = useState('All Specialties');
  const [userLocation, setUserLocation] = useState<[number, number]>([40.7128, -74.0060]);
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    filterDoctors();
  }, [selectedSpecialty]);

  const filterDoctors = () => {
    if (selectedSpecialty === 'All Specialties') {
      setFilteredDoctors(doctors);
    } else {
      setFilteredDoctors(doctors.filter(doctor => doctor.specialty === selectedSpecialty));
    }
  };

  const handleSearch = async () => {
    setIsLoading(true);
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // In a real app, you would geocode the location and fetch nearby doctors
    console.log('Searching for doctors near:', searchLocation);
    
    setIsLoading(false);
  };

  const handleUseCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          const { latitude, longitude } = position.coords;
          setUserLocation([latitude, longitude]);
          setSearchLocation('Current Location');
          // Fetch doctors near current location
          console.log('Using current location:', latitude, longitude);
        },
        (error) => {
          console.error('Error getting location:', error);
        }
      );
    } else {
      console.error('Geolocation is not supported by this browser.');
    }
  };

  const renderStars = (rating: number) => {
    return Array.from({ length: 5 }, (_, index) => (
      <Star
        key={index}
        className={`h-4 w-4 ${
          index < Math.floor(rating) ? 'text-yellow-400 fill-current' : 'text-gray-300'
        }`}
      />
    ));
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto p-2 md:p-4 lg:p-6">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-md p-4 md:p-6 mb-4 md:mb-6">
          <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-800 mb-4">Find Doctors Nearby</h1>
          
          {/* Search Bar */}
          <div className="flex flex-col md:flex-row lg:flex-row gap-4 mb-4">
            <div className="flex-1 relative">
              <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                value={searchLocation}
                onChange={(e) => setSearchLocation(e.target.value)}
                placeholder="Enter location..."
                className="w-full pl-10 pr-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
              />
            </div>
            <div className="flex flex-col sm:flex-row gap-2 md:gap-4">
              <button
                onClick={handleUseCurrentLocation}
                className="px-3 md:px-4 py-2 md:py-3 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-lg transition-colors duration-200 whitespace-nowrap text-sm md:text-base"
              >
                Use Current Location
              </button>
              <button
                onClick={handleSearch}
                disabled={isLoading}
                className="px-4 md:px-6 py-2 md:py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white rounded-lg transition-colors duration-200 flex items-center justify-center space-x-2 text-sm md:text-base"
              >
                <Search className="h-5 w-5" />
                <span>{isLoading ? 'Searching...' : 'Search'}</span>
              </button>
            </div>
          </div>

          {/* Specialty Filter */}
          <div className="flex flex-col md:flex-row items-start md:items-center space-y-2 md:space-y-0 md:space-x-4">
            <Filter className="h-5 w-5 text-gray-500" />
            <select
              value={selectedSpecialty}
              onChange={(e) => setSelectedSpecialty(e.target.value)}
              className="w-full md:w-auto px-3 md:px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
            >
              {specialties.map((specialty) => (
                <option key={specialty} value={specialty}>
                  {specialty}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
          {/* Doctors List */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-3 md:p-4 max-h-96 lg:max-h-screen overflow-y-auto">
              <h2 className="text-lg md:text-xl font-bold text-gray-800 mb-4">
                Doctors Found ({filteredDoctors.length})
              </h2>
              
              <div className="space-y-4">
                {filteredDoctors.map((doctor) => (
                  <div key={doctor.id} className="border border-gray-200 rounded-lg p-3 md:p-4 hover:shadow-md transition-shadow duration-200">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold text-gray-800 text-sm md:text-base">{doctor.name}</h3>
                      <div className="flex items-center space-x-1">
                        {renderStars(doctor.rating)}
                        <span className="text-xs md:text-sm text-gray-600 ml-1">{doctor.rating}</span>
                      </div>
                    </div>
                    
                    <p className="text-blue-600 font-medium text-xs md:text-sm mb-1">{doctor.specialty}</p>
                    <p className="text-gray-600 text-xs md:text-sm mb-2 truncate">{doctor.address}</p>
                    <p className="text-green-600 font-medium text-xs md:text-sm mb-3">{doctor.distance} away</p>
                    
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between space-y-2 md:space-y-0">
                      <div className="flex items-center space-x-2 text-gray-600 truncate">
                        <Phone className="h-4 w-4" />
                        <span className="text-xs md:text-sm truncate">{doctor.phone}</span>
                      </div>
                      <button className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-xs md:text-sm transition-colors duration-200 w-full md:w-auto">
                        Book
                      </button>
                    </div>
                  </div>
                ))}
                <p className="text-sm md:text-base">No medical conditions recorded</p>
              </div>
            </div>
          </div>

          {/* Map */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md overflow-hidden h-80 md:h-96 lg:h-[600px]">
              <MapContainer
                center={userLocation}
                zoom={13}
                style={{ height: '100%', width: '100%' }}
              >
                <TileLayer
                  url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                  attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                />
                
                {filteredDoctors.map((doctor) => (
                  <Marker key={doctor.id} position={[doctor.lat, doctor.lng]}>
                    <Popup>
                      <div className="p-2 min-w-48 md:min-w-56">
                        <h3 className="font-semibold text-gray-800 text-sm md:text-base">{doctor.name}</h3>
                        <p className="text-blue-600 text-sm md:text-base">{doctor.specialty}</p>
                        <p className="text-gray-600 text-xs truncate">{doctor.address}</p>
                        <div className="flex items-center space-x-1 mt-1">
                          {renderStars(doctor.rating)}
                          <span className="text-xs text-gray-600 ml-1">{doctor.rating}</span>
                        </div>
                        <p className="text-xs text-gray-600 mt-1 truncate">{doctor.phone}</p>
                        <button className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-1 rounded text-xs md:text-sm mt-2 transition-colors duration-200 w-full">
                          Book Appointment
                        </button>
                      </div>
                    </Popup>
                  </Marker>
                ))}
              </MapContainer>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DoctorsPage;
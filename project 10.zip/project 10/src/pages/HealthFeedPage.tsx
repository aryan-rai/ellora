import React, { useState, useEffect } from 'react';
import { Heart, TrendingUp, Users, Calendar, Clock, ThumbsUp, MessageCircle, Share2, Bookmark, Filter, Search, ExternalLink, Globe } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface NewsArticle {
  id: string;
  title: string;
  summary: string;
  content: string;
  author: string;
  publication: string;
  category: string;
  timestamp: string;
  readTime: string;
  likes: number;
  comments: number;
  shares: number;
  isLiked: boolean;
  isBookmarked: boolean;
  image: string;
  tags: string[];
  sourceUrl: string;
  isBreaking: boolean;
}

interface HealthTip {
  id: string;
  tip: string;
  category: string;
  icon: string;
}

const mockArticles: NewsArticle[] = [
  {
    id: '1',
    title: 'New COVID-19 Variant Shows Increased Transmissibility, WHO Reports',
    summary: 'World Health Organization announces discovery of new COVID-19 variant with enhanced transmission rates, prompting renewed vaccination campaigns globally.',
    content: 'The World Health Organization has identified a new variant of COVID-19 that demonstrates significantly higher transmissibility rates compared to previous strains. Health officials worldwide are implementing enhanced surveillance measures and accelerating booster vaccination programs to combat the spread.',
    author: 'Dr. Maria Rodriguez',
    publication: 'Global Health News',
    category: 'Breaking News',
    timestamp: '2024-01-22T15:30:00Z',
    readTime: '4 min read',
    likes: 342,
    comments: 89,
    shares: 156,
    isLiked: false,
    isBookmarked: false,
    image: 'https://images.pexels.com/photos/3873193/pexels-photo-3873193.jpeg?auto=compress&cs=tinysrgb&w=800',
    tags: ['covid-19', 'pandemic', 'vaccination', 'who'],
    sourceUrl: 'https://who.int/news',
    isBreaking: true
  },
  {
    id: '2',
    title: 'Breakthrough in Alzheimer\'s Research: New Drug Shows Promise in Clinical Trials',
    summary: 'Revolutionary Alzheimer\'s treatment demonstrates significant cognitive improvement in Phase III trials, offering hope for millions of patients worldwide.',
    content: 'A groundbreaking study published in the New England Journal of Medicine reveals that a new Alzheimer\'s drug has shown remarkable results in slowing cognitive decline. The Phase III clinical trial involved over 1,800 participants and demonstrated a 27% reduction in cognitive decline over 18 months.',
    author: 'Dr. James Thompson',
    publication: 'Medical Research Today',
    category: 'Research',
    timestamp: '2024-01-22T12:45:00Z',
    readTime: '6 min read',
    likes: 567,
    comments: 134,
    shares: 289,
    isLiked: true,
    isBookmarked: true,
    image: 'https://images.pexels.com/photos/3825527/pexels-photo-3825527.jpeg?auto=compress&cs=tinysrgb&w=800',
    tags: ['alzheimers', 'research', 'clinical-trials', 'neurology'],
    sourceUrl: 'https://nejm.org',
    isBreaking: false
  },
  {
    id: '3',
    title: 'Global Malaria Cases Drop to Historic Low Following New Prevention Campaign',
    summary: 'WHO reports 40% reduction in malaria cases worldwide after implementing innovative prevention strategies and improved access to treatment.',
    content: 'The World Health Organization announced today that global malaria cases have reached their lowest point in recorded history, with a 40% reduction compared to last year. This achievement is attributed to widespread distribution of insecticide-treated nets, improved diagnostic tools, and enhanced community health programs.',
    author: 'Dr. Sarah Chen',
    publication: 'International Health Journal',
    category: 'Global Health',
    timestamp: '2024-01-22T10:20:00Z',
    readTime: '5 min read',
    likes: 423,
    comments: 67,
    shares: 198,
    isLiked: false,
    isBookmarked: false,
    image: 'https://images.pexels.com/photos/3938023/pexels-photo-3938023.jpeg?auto=compress&cs=tinysrgb&w=800',
    tags: ['malaria', 'prevention', 'global-health', 'who'],
    sourceUrl: 'https://who.int/malaria',
    isBreaking: false
  },
  {
    id: '4',
    title: 'Heart Disease Prevention: Mediterranean Diet Reduces Risk by 30%',
    summary: 'Large-scale study confirms Mediterranean diet\'s effectiveness in preventing cardiovascular disease, with participants showing significant health improvements.',
    content: 'A comprehensive 10-year study involving 25,000 participants has conclusively demonstrated that following a Mediterranean diet can reduce the risk of heart disease by up to 30%. The research, published in the American Heart Association journal, highlights the importance of olive oil, fish, and fresh vegetables in maintaining cardiovascular health.',
    author: 'Dr. Michael Foster',
    publication: 'Cardiology Weekly',
    category: 'Nutrition',
    timestamp: '2024-01-22T08:15:00Z',
    readTime: '7 min read',
    likes: 789,
    comments: 156,
    shares: 334,
    isLiked: true,
    isBookmarked: false,
    image: 'https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=800',
    tags: ['heart-disease', 'mediterranean-diet', 'nutrition', 'prevention'],
    sourceUrl: 'https://heart.org',
    isBreaking: false
  },
  {
    id: '5',
    title: 'Mental Health Crisis: Teen Depression Rates Surge Post-Pandemic',
    summary: 'New CDC data reveals alarming increase in depression and anxiety among teenagers, prompting calls for enhanced mental health support in schools.',
    content: 'The Centers for Disease Control and Prevention released troubling statistics showing a 25% increase in depression rates among teenagers since the pandemic began. Mental health experts are calling for immediate action to expand counseling services and implement comprehensive mental health programs in educational institutions.',
    author: 'Dr. Lisa Park',
    publication: 'Mental Health Today',
    category: 'Mental Health',
    timestamp: '2024-01-21T16:30:00Z',
    readTime: '5 min read',
    likes: 234,
    comments: 78,
    shares: 145,
    isLiked: false,
    isBookmarked: true,
    image: 'https://images.pexels.com/photos/3760067/pexels-photo-3760067.jpeg?auto=compress&cs=tinysrgb&w=800',
    tags: ['mental-health', 'teenagers', 'depression', 'pandemic'],
    sourceUrl: 'https://cdc.gov/mentalhealth',
    isBreaking: false
  },
  {
    id: '6',
    title: 'Gene Therapy Breakthrough: First Successful Treatment for Rare Blood Disorder',
    summary: 'Revolutionary gene therapy provides cure for patients with beta-thalassemia, marking a milestone in personalized medicine.',
    content: 'Medical researchers have achieved a groundbreaking success in gene therapy, successfully treating patients with beta-thalassemia, a rare inherited blood disorder. The treatment involves modifying the patient\'s own stem cells to produce healthy red blood cells, eliminating the need for lifelong blood transfusions.',
    author: 'Dr. Robert Kim',
    publication: 'Gene Therapy Review',
    category: 'Research',
    timestamp: '2024-01-21T14:45:00Z',
    readTime: '8 min read',
    likes: 445,
    comments: 92,
    shares: 267,
    isLiked: false,
    isBookmarked: false,
    image: 'https://images.pexels.com/photos/3938022/pexels-photo-3938022.jpeg?auto=compress&cs=tinysrgb&w=800',
    tags: ['gene-therapy', 'blood-disorders', 'personalized-medicine', 'breakthrough'],
    sourceUrl: 'https://nature.com/gene-therapy',
    isBreaking: false
  }
];

const healthTips: HealthTip[] = [
  { id: '1', tip: 'Stay updated with latest health news to make informed decisions', category: 'Information', icon: '📰' },
  { id: '2', tip: 'Verify health information from credible medical sources', category: 'Safety', icon: '✅' },
  { id: '3', tip: 'Discuss news about treatments with your healthcare provider', category: 'Communication', icon: '💬' },
  { id: '4', tip: 'Follow evidence-based health recommendations', category: 'Evidence', icon: '🔬' }
];

const categories = ['All', 'Breaking News', 'Research', 'Global Health', 'Nutrition', 'Mental Health', 'Disease Prevention'];

const HealthFeedPage: React.FC = () => {
  const [articles, setArticles] = useState<NewsArticle[]>(mockArticles);
  const [filteredArticles, setFilteredArticles] = useState<NewsArticle[]>(mockArticles);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [currentTipIndex, setCurrentTipIndex] = useState(0);

  useEffect(() => {
    fetchArticlesFromDatabase();
    filterArticles();
  }, [selectedCategory, searchQuery, articles]);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentTipIndex((prev) => (prev + 1) % healthTips.length);
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  const filterArticles = () => {
    let filtered = articles;

    if (selectedCategory !== 'All') {
      filtered = filtered.filter(article => article.category === selectedCategory);
    }

    if (searchQuery) {
      filtered = filtered.filter(article =>
        article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.summary.toLowerCase().includes(searchQuery.toLowerCase()) ||
        article.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    // Sort by breaking news first, then by timestamp
    filtered.sort((a, b) => {
      if (a.isBreaking && !b.isBreaking) return -1;
      if (!a.isBreaking && b.isBreaking) return 1;
      return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
    });

    setFilteredArticles(filtered);
  };

  const handleLike = (articleId: string) => {
    setArticles(prev => prev.map(article => {
      if (article.id === articleId) {
        return {
          ...article,
          isLiked: !article.isLiked,
          likes: article.isLiked ? article.likes - 1 : article.likes + 1
        };
      }
      return article;
    }));
  };

  const handleBookmark = (articleId: string) => {
    setArticles(prev => prev.map(article => {
      if (article.id === articleId) {
        return { ...article, isBookmarked: !article.isBookmarked };
      }
      return article;
    }));
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const articleTime = new Date(timestamp);
    const diffInHours = Math.floor((now.getTime() - articleTime.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    return `${Math.floor(diffInHours / 24)}d ago`;
  };


  const fetchArticlesFromDatabase = async () => {
    try {
      const { data, error } = await supabase
        .from('health_articles')
        .select('*')
        .eq('is_published', true)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching articles:', error);
        return;
      }

      if (data && data.length > 0) {
        // Transform database articles to match our interface
        const transformedArticles = data.map(article => ({
          id: article.id,
          title: article.title,
          summary: article.summary,
          content: article.content,
          author: article.author,
          publication: article.publication,
          category: article.category,
          timestamp: article.created_at,
          readTime: `${Math.ceil(article.content.length / 200)} min read`,
          likes: Math.floor(Math.random() * 1000) + 100,
          comments: Math.floor(Math.random() * 200) + 20,
          shares: Math.floor(Math.random() * 500) + 50,
          isLiked: false,
          isBookmarked: false,
          image: article.image_url || 'https://images.pexels.com/photos/3873193/pexels-photo-3873193.jpeg?auto=compress&cs=tinysrgb&w=800',
          tags: article.tags || [],
          sourceUrl: article.source_url || '#',
          isBreaking: article.is_breaking
        }));
        
        setArticles(transformedArticles);
      }
    } catch (error) {
      console.error('Error fetching articles:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto p-2 md:p-4 lg:p-6">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-md p-4 md:p-6 mb-4 md:mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-blue-600 to-green-500 p-3 rounded-xl">
                <Globe className="h-6 w-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-800">Health News & Articles</h1>
                <p className="text-sm md:text-base text-gray-600">Stay informed with the latest health and medical news</p>
              </div>
            </div>
            <div className="hidden md:flex items-center space-x-4">
              <div className="flex items-center space-x-2 text-sm md:text-base text-gray-600">
                <TrendingUp className="h-4 w-4" />
                <span>Breaking News</span>
              </div>
              <div className="flex items-center space-x-2 text-sm md:text-base text-gray-600">
                <Users className="h-4 w-4" />
                <span>1.2M Readers</span>
              </div>
            </div>
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col md:flex-row lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search health news, diseases, treatments, or research..."
                className="w-full pl-10 pr-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
              />
            </div>
            <div className="flex flex-col md:flex-row items-start md:items-center space-y-2 md:space-y-0 md:space-x-2">
              <Filter className="h-5 w-5 text-gray-500" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full md:w-auto px-3 md:px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
              >
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 md:gap-6">
          {/* Sidebar */}
          <div className="lg:col-span-1 space-y-4 md:space-y-6 order-2 lg:order-1">
            {/* Daily Health Tip */}
            <div className="bg-gradient-to-br from-blue-500 to-green-500 rounded-lg p-4 md:p-6 text-white">
              <h3 className="text-base md:text-lg font-bold mb-3">💡 Health News Tip</h3>
              <div className="bg-white/20 rounded-lg p-4 backdrop-blur-sm">
                <div className="text-2xl mb-2">{healthTips[currentTipIndex].icon}</div>
                <p className="text-xs md:text-sm font-medium">{healthTips[currentTipIndex].tip}</p>
                <span className="text-xs text-blue-100 mt-2 block">
                  {healthTips[currentTipIndex].category}
                </span>
              </div>
            </div>

            {/* Reading Stats */}
            <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
              <h3 className="text-base md:text-lg font-bold text-gray-800 mb-4">Your Reading</h3>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm md:text-base text-gray-600">Articles Read</span>
                  <span className="font-bold text-blue-600">47</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm md:text-base text-gray-600">Articles Saved</span>
                  <span className="font-bold text-green-600">12</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm md:text-base text-gray-600">Reading Time</span>
                  <span className="font-bold text-purple-600">3.2h</span>
                </div>
              </div>
            </div>

            {/* Trending Topics */}
            <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
              <h3 className="text-base md:text-lg font-bold text-gray-800 mb-4">Trending Topics</h3>
              <div className="space-y-2">
                {['#COVID19Updates', '#AlzheimersResearch', '#HeartHealth', '#MentalHealthAwareness', '#GeneTherapy'].map((tag, index) => (
                  <div key={tag} className="flex items-center justify-between">
                    <span className="text-blue-600 text-xs md:text-sm font-medium truncate">{tag}</span>
                    <span className="text-xs text-gray-500">{Math.floor(Math.random() * 500) + 100}k</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Breaking News Alert */}
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 md:p-4">
              <div className="flex items-center space-x-2 mb-2">
                <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
                <span className="text-red-700 font-bold text-xs md:text-sm">BREAKING NEWS</span>
              </div>
              <p className="text-red-600 text-xs md:text-sm">
                New health advisory issued by WHO regarding emerging infectious disease patterns.
              </p>
            </div>
          </div>

          {/* Main Feed */}
          <div className="lg:col-span-3 order-1 lg:order-2">
            <div className="space-y-4 md:space-y-6">
              {filteredArticles.map((article) => (
                <div key={article.id} className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow duration-200">
                  {/* Breaking News Badge */}
                  {article.isBreaking && (
                    <div className="bg-red-600 text-white px-3 md:px-4 py-2 text-xs md:text-sm font-bold">
                      🚨 BREAKING NEWS
                    </div>
                  )}

                  {/* Article Header */}
                  <div className="p-4 md:p-6 pb-4">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex items-center space-x-3">
                        <div className="w-10 md:w-12 h-10 md:h-12 bg-gradient-to-r from-blue-600 to-green-500 rounded-full flex items-center justify-center">
                          <span className="text-white font-bold text-sm md:text-lg">
                            {article.publication.split(' ').map(n => n[0]).join('')}
                          </span>
                        </div>
                        <div>
                          <h4 className="font-semibold text-gray-800 text-sm md:text-base">{article.author}</h4>
                          <p className="text-xs md:text-sm text-gray-600 truncate">{article.publication}</p>
                          <div className="flex items-center space-x-2 mt-1">
                            <Clock className="h-3 w-3 text-gray-400" />
                            <span className="text-xs text-gray-500">{formatTimeAgo(article.timestamp)}</span>
                            <span className="text-xs text-gray-500">•</span>
                            <span className="text-xs text-gray-500">{article.readTime}</span>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                              article.category === 'Breaking News' ? 'bg-red-100 text-red-700' :
                              article.category === 'Research' ? 'bg-purple-100 text-purple-700' :
                              article.category === 'Global Health' ? 'bg-blue-100 text-blue-700' :
                              article.category === 'Nutrition' ? 'bg-green-100 text-green-700' :
                              article.category === 'Mental Health' ? 'bg-indigo-100 text-indigo-700' :
                              'bg-orange-100 text-orange-700'
                            }`}>
                              {article.category}
                            </span>
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => handleBookmark(article.id)}
                        className={`p-2 rounded-full transition-colors duration-200 ${
                          article.isBookmarked ? 'text-yellow-500 bg-yellow-50' : 'text-gray-400 hover:text-yellow-500 hover:bg-yellow-50'
                        }`}
                      >
                        <Bookmark className="h-5 w-5" />
                      </button>
                    </div>

                    <h2 className="text-lg md:text-xl font-bold text-gray-800 mb-3">{article.title}</h2>
                    <p className="text-sm md:text-base text-gray-600 leading-relaxed mb-4">{article.summary}</p>

                    {/* Tags */}
                    <div className="flex flex-wrap gap-1 md:gap-2 mb-4">
                      {article.tags.map((tag) => (
                        <span key={tag} className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded-full truncate">
                          #{tag}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Article Image */}
                  <div className="px-4 md:px-6 pb-4">
                    <img
                      src={article.image}
                      alt={article.title}
                      className="w-full h-48 md:h-64 object-cover rounded-lg"
                    />
                  </div>

                  {/* Article Actions */}
                  <div className="px-4 md:px-6 py-4 border-t border-gray-100">
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between space-y-3 md:space-y-0">
                      <div className="flex items-center space-x-4 md:space-x-6">
                        <button
                          onClick={() => handleLike(article.id)}
                          className={`flex items-center space-x-2 transition-colors duration-200 ${
                            article.isLiked ? 'text-red-500' : 'text-gray-500 hover:text-red-500'
                          }`}
                        >
                          <ThumbsUp className={`h-5 w-5 ${article.isLiked ? 'fill-current' : ''}`} />
                          <span className="text-xs md:text-sm font-medium">{article.likes}</span>
                        </button>
                        <button className="flex items-center space-x-2 text-gray-500 hover:text-blue-500 transition-colors duration-200">
                          <MessageCircle className="h-5 w-5" />
                          <span className="text-xs md:text-sm font-medium">{article.comments}</span>
                        </button>
                        <button className="flex items-center space-x-2 text-gray-500 hover:text-green-500 transition-colors duration-200">
                          <Share2 className="h-5 w-5" />
                          <span className="text-xs md:text-sm font-medium">{article.shares}</span>
                        </button>
                      </div>
                      <div className="flex items-center space-x-2 md:space-x-3">
                        <a
                          href={article.sourceUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex items-center space-x-1 text-blue-600 hover:text-blue-700 text-xs md:text-sm font-medium"
                        >
                          <ExternalLink className="h-4 w-4" />
                          <span>Source</span>
                        </a>
                        <button className="text-blue-600 hover:text-blue-700 text-xs md:text-sm font-medium">
                          Read Full Article
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {filteredArticles.length === 0 && (
                <div className="bg-white rounded-lg shadow-md p-12 text-center">
                  <div className="text-gray-400 mb-4">
                    <Search className="h-12 w-12 mx-auto" />
                  </div>
                  <h3 className="text-base md:text-lg font-medium text-gray-800 mb-2">No articles found</h3>
                  <p className="text-sm md:text-base text-gray-600">Try adjusting your search or filter criteria</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HealthFeedPage;
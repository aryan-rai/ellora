import React, { useState, useEffect } from 'react';
import { AlertTriangle, Bell, MapPin, Clock, ExternalLink, Filter, Search, X, CheckCircle, AlertCircle, Info } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface Alert {
  id: string;
  title: string;
  description: string;
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info';
  category: string;
  location: string;
  timestamp: string;
  source: string;
  sourceLink: string;
  isRead: boolean;
  affectedArea: string;
  estimatedImpact: string;
}

const mockAlerts: Alert[] = [
  {
    id: '1',
    title: 'Flu Outbreak Alert - Manhattan',
    description: 'Significant increase in flu cases reported across Manhattan hospitals. Health officials recommend immediate vaccination and enhanced hygiene measures.',
    severity: 'high',
    category: 'Disease Outbreak',
    location: 'Manhattan, NY',
    timestamp: '2024-01-22T14:30:00Z',
    source: 'NYC Health Department',
    sourceLink: 'https://www1.nyc.gov/site/doh/health/health-topics/flu.page',
    isRead: false,
    affectedArea: '~500,000 residents',
    estimatedImpact: 'High transmission risk'
  },
  {
    id: '2',
    title: 'Air Quality Warning',
    description: 'Poor air quality detected due to wildfire smoke. Sensitive individuals should limit outdoor activities.',
    severity: 'medium',
    category: 'Environmental',
    location: 'Brooklyn, NY',
    timestamp: '2024-01-22T12:15:00Z',
    source: 'EPA',
    sourceLink: 'https://www.epa.gov/air-quality',
    isRead: false,
    affectedArea: '~2.7M residents',
    estimatedImpact: 'Respiratory concerns'
  },
  {
    id: '3',
    title: 'Food Safety Alert - Restaurant Chain',
    description: 'Multiple cases of food poisoning linked to XYZ Restaurant chain. Investigation ongoing.',
    severity: 'critical',
    category: 'Food Safety',
    location: 'Queens, NY',
    timestamp: '2024-01-22T10:45:00Z',
    source: 'FDA',
    sourceLink: 'https://www.fda.gov/food/recalls-outbreaks-emergencies',
    isRead: true,
    affectedArea: '15 restaurant locations',
    estimatedImpact: '45 confirmed cases'
  },
  {
    id: '4',
    title: 'Heat Wave Advisory',
    description: 'Extreme heat expected for the next 3 days. Stay hydrated and avoid prolonged sun exposure.',
    severity: 'medium',
    category: 'Weather',
    location: 'Bronx, NY',
    timestamp: '2024-01-22T09:20:00Z',
    source: 'National Weather Service',
    sourceLink: 'https://www.weather.gov',
    isRead: false,
    affectedArea: '~1.4M residents',
    estimatedImpact: 'Heat-related illness risk'
  },
  {
    id: '5',
    title: 'Water Quality Notice',
    description: 'Temporary water quality advisory for Staten Island residents. Boil water before consumption.',
    severity: 'high',
    category: 'Water Safety',
    location: 'Staten Island, NY',
    timestamp: '2024-01-22T08:00:00Z',
    source: 'NYC DEP',
    sourceLink: 'https://www1.nyc.gov/site/dep/water/water-quality.page',
    isRead: false,
    affectedArea: '~475,000 residents',
    estimatedImpact: 'Water contamination risk'
  },
  {
    id: '6',
    title: 'Vaccination Drive Update',
    description: 'New COVID-19 booster shots available at all health centers. Schedule your appointment today.',
    severity: 'info',
    category: 'Public Health',
    location: 'New York City',
    timestamp: '2024-01-22T07:30:00Z',
    source: 'NYC Health',
    sourceLink: 'https://www1.nyc.gov/site/doh/covid/covid-19-vaccines.page',
    isRead: true,
    affectedArea: 'All NYC residents',
    estimatedImpact: 'Prevention opportunity'
  }
];

const categories = ['All', 'Disease Outbreak', 'Environmental', 'Food Safety', 'Weather', 'Water Safety', 'Public Health'];
const severityLevels = ['All', 'Critical', 'High', 'Medium', 'Low', 'Info'];

const LiveAlertsPage: React.FC = () => {
  const [alerts, setAlerts] = useState<Alert[]>(mockAlerts);
  const [filteredAlerts, setFilteredAlerts] = useState<Alert[]>(mockAlerts);
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedSeverity, setSelectedSeverity] = useState('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedAlert, setSelectedAlert] = useState<Alert | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    fetchAlertsFromDatabase();
    filterAlerts();
    updateUnreadCount();
  }, [selectedCategory, selectedSeverity, searchQuery, alerts]);

  const filterAlerts = () => {
    let filtered = alerts;

    if (selectedCategory !== 'All') {
      filtered = filtered.filter(alert => alert.category === selectedCategory);
    }

    if (selectedSeverity !== 'All') {
      filtered = filtered.filter(alert => alert.severity === selectedSeverity.toLowerCase());
    }

    if (searchQuery) {
      filtered = filtered.filter(alert =>
        alert.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        alert.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        alert.location.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Sort by timestamp (newest first) and severity
    filtered.sort((a, b) => {
      const severityOrder = { critical: 4, high: 3, medium: 2, low: 1, info: 0 };
      const severityDiff = severityOrder[b.severity] - severityOrder[a.severity];
      if (severityDiff !== 0) return severityDiff;
      return new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime();
    });

    setFilteredAlerts(filtered);
  };

  const updateUnreadCount = () => {
    const count = alerts.filter(alert => !alert.isRead).length;
    setUnreadCount(count);
  };

  const fetchAlertsFromDatabase = async () => {
    try {
      const { data, error } = await supabase
        .from('health_alerts')
        .select('*')
        .eq('is_active', true)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Error fetching alerts:', error);
        return;
      }

      if (data && data.length > 0) {
        // Transform database alerts to match our interface
        const transformedAlerts = data.map(alert => ({
          id: alert.id,
          title: alert.title,
          description: alert.description,
          severity: alert.severity,
          category: alert.category,
          location: alert.location,
          timestamp: alert.created_at,
          source: alert.source,
          sourceLink: alert.source_link || '#',
          isRead: false,
          affectedArea: alert.affected_area || 'Unknown',
          estimatedImpact: alert.estimated_impact || 'Under assessment'
        }));
        
        setAlerts(transformedAlerts);
      }
    } catch (error) {
      console.error('Error fetching alerts:', error);
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'text-red-700 bg-red-100 border-red-200';
      case 'high': return 'text-orange-700 bg-orange-100 border-orange-200';
      case 'medium': return 'text-yellow-700 bg-yellow-100 border-yellow-200';
      case 'low': return 'text-blue-700 bg-blue-100 border-blue-200';
      case 'info': return 'text-green-700 bg-green-100 border-green-200';
      default: return 'text-gray-700 bg-gray-100 border-gray-200';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical': return <AlertTriangle className="h-5 w-5" />;
      case 'high': return <AlertCircle className="h-5 w-5" />;
      case 'medium': return <AlertCircle className="h-5 w-5" />;
      case 'low': return <Info className="h-5 w-5" />;
      case 'info': return <CheckCircle className="h-5 w-5" />;
      default: return <Bell className="h-5 w-5" />;
    }
  };

  const handleAlertClick = (alert: Alert) => {
    setSelectedAlert(alert);
    setIsDrawerOpen(true);
    
    // Mark as read
    if (!alert.isRead) {
      setAlerts(prev => prev.map(a => 
        a.id === alert.id ? { ...a, isRead: true } : a
      ));
    }
  };

  const markAllAsRead = () => {
    setAlerts(prev => prev.map(alert => ({ ...alert, isRead: true })));
  };

  const formatTimeAgo = (timestamp: string) => {
    const now = new Date();
    const alertTime = new Date(timestamp);
    const diffInMinutes = Math.floor((now.getTime() - alertTime.getTime()) / (1000 * 60));
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto p-2 md:p-4 lg:p-6">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-md p-4 md:p-6 mb-4 md:mb-6">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-3">
              <div className="bg-gradient-to-r from-red-600 to-orange-500 p-3 rounded-xl relative">
                <Bell className="h-6 w-6 text-white" />
                {unreadCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 md:h-6 md:w-6 flex items-center justify-center font-bold">
                    {unreadCount}
                  </span>
                )}
              </div>
              <div>
                <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-800">Live Health Alerts</h1>
                <p className="text-sm md:text-base text-gray-600">Real-time health and safety notifications for your area</p>
              </div>
            </div>
            <div className="flex flex-col md:flex-row items-end md:items-center space-y-2 md:space-y-0 md:space-x-4">
              <div className="text-xs md:text-sm text-gray-600">
                <span className="font-medium">{unreadCount}</span> unread alerts
              </div>
              {unreadCount > 0 && (
                <button
                  onClick={markAllAsRead}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-3 md:px-4 py-2 rounded-lg text-xs md:text-sm transition-colors duration-200 whitespace-nowrap"
                >
                  Mark All Read
                </button>
              )}
            </div>
          </div>

          {/* Search and Filters */}
          <div className="flex flex-col md:flex-row lg:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search alerts by location, type, or description..."
                className="w-full pl-10 pr-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
              />
            </div>
            <div className="flex flex-col md:flex-row items-start md:items-center space-y-2 md:space-y-0 md:space-x-4">
              <div className="flex items-center space-x-2 w-full md:w-auto">
                <Filter className="h-5 w-5 text-gray-500" />
                <select
                  value={selectedCategory}
                  onChange={(e) => setSelectedCategory(e.target.value)}
                  className="flex-1 md:flex-none px-3 md:px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
                >
                  {categories.map((category) => (
                    <option key={category} value={category}>
                      {category}
                    </option>
                  ))}
                </select>
              </div>
              <select
                value={selectedSeverity}
                onChange={(e) => setSelectedSeverity(e.target.value)}
                className="w-full md:w-auto px-3 md:px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
              >
                {severityLevels.map((severity) => (
                  <option key={severity} value={severity}>
                    {severity} Severity
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Alerts List */}
        <div className="space-y-3 md:space-y-4">
          {filteredAlerts.map((alert) => (
            <div
              key={alert.id}
              onClick={() => handleAlertClick(alert)}
              className={`bg-white rounded-lg shadow-md p-4 md:p-6 cursor-pointer hover:shadow-lg transition-all duration-200 border-l-4 ${
                alert.severity === 'critical' ? 'border-red-500' :
                alert.severity === 'high' ? 'border-orange-500' :
                alert.severity === 'medium' ? 'border-yellow-500' :
                alert.severity === 'low' ? 'border-blue-500' :
                'border-green-500'
              } ${!alert.isRead ? 'bg-blue-50' : ''}`}
            >
              <div className="flex flex-col md:flex-row items-start justify-between space-y-3 md:space-y-0">
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 md:space-x-3 mb-2">
                    <div className={`flex items-center space-x-2 px-3 py-1 rounded-full border ${getSeverityColor(alert.severity)}`}>
                      {getSeverityIcon(alert.severity)}
                      <span className="text-xs md:text-sm font-medium uppercase">{alert.severity}</span>
                    </div>
                    <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs md:text-sm rounded-full">
                      {alert.category}
                    </span>
                    {!alert.isRead && (
                      <span className="w-3 h-3 bg-blue-500 rounded-full"></span>
                    )}
                  </div>
                  
                  <h3 className="text-lg md:text-xl font-bold text-gray-800 mb-2">{alert.title}</h3>
                  <p className="text-sm md:text-base text-gray-600 mb-3 line-clamp-2">{alert.description}</p>
                  
                  <div className="flex flex-col md:flex-row items-start md:items-center space-y-1 md:space-y-0 md:space-x-6 text-xs md:text-sm text-gray-500">
                    <div className="flex items-center space-x-1">
                      <MapPin className="h-4 w-4" />
                      <span className="truncate">{alert.location}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Clock className="h-4 w-4" />
                      <span>{formatTimeAgo(alert.timestamp)}</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <span className="truncate">Impact: {alert.estimatedImpact}</span>
                    </div>
                  </div>
                </div>
                
                <div className="md:ml-4 text-left md:text-right w-full md:w-auto">
                  <div className="text-xs md:text-sm text-gray-500 mb-2 truncate">Source: {alert.source}</div>
                  <button className="text-blue-600 hover:text-blue-700 text-xs md:text-sm font-medium">
                    View Details →
                  </button>
                </div>
              </div>
            </div>
          ))}

          {filteredAlerts.length === 0 && (
            <div className="bg-white rounded-lg shadow-md p-8 sm:p-12 text-center">
              <div className="text-gray-400 mb-4">
                <Bell className="h-12 w-12 mx-auto" />
              </div>
              <h3 className="text-base md:text-lg font-medium text-gray-800 mb-2">No alerts found</h3>
              <p className="text-sm md:text-base text-gray-600">Try adjusting your search or filter criteria</p>
            </div>
          )}
        </div>
      </div>

      {/* Alert Details Drawer */}
      {isDrawerOpen && selectedAlert && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          <div className="absolute inset-0 bg-black bg-opacity-50" onClick={() => setIsDrawerOpen(false)}></div>
          
          <div className="absolute right-0 top-0 h-full w-full md:max-w-xl lg:max-w-2xl bg-white shadow-xl transform transition-transform duration-300 ease-in-out">
            <div className="flex flex-col h-full">
              {/* Header */}
              <div className="flex items-center justify-between p-4 md:p-6 border-b border-gray-200">
                <h2 className="text-lg md:text-xl font-bold text-gray-800">Alert Details</h2>
                <button
                  onClick={() => setIsDrawerOpen(false)}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors duration-200"
                >
                  <X className="h-5 w-5 text-gray-500" />
                </button>
              </div>

              {/* Content */}
              <div className="flex-1 overflow-y-auto p-4 md:p-6">
                <div className="space-y-4 md:space-y-6">
                  {/* Alert Header */}
                  <div>
                    <div className="flex flex-wrap items-center gap-2 md:space-x-3 mb-4">
                      <div className={`flex items-center space-x-2 px-4 py-2 rounded-full border ${getSeverityColor(selectedAlert.severity)}`}>
                        {getSeverityIcon(selectedAlert.severity)}
                        <span className="text-sm md:text-base font-medium uppercase">{selectedAlert.severity} ALERT</span>
                      </div>
                      <span className="px-3 py-1 bg-gray-100 text-gray-600 rounded-full text-sm md:text-base">
                        {selectedAlert.category}
                      </span>
                    </div>
                    
                    <h1 className="text-xl md:text-2xl font-bold text-gray-800 mb-4">{selectedAlert.title}</h1>
                  </div>

                  {/* Alert Info */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center space-x-2 text-gray-600 mb-2">
                        <MapPin className="h-5 w-5" />
                        <span className="text-sm md:text-base font-medium">Location</span>
                      </div>
                      <p className="text-sm md:text-base text-gray-800 font-medium">{selectedAlert.location}</p>
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center space-x-2 text-gray-600 mb-2">
                        <Clock className="h-5 w-5" />
                        <span className="text-sm md:text-base font-medium">Reported</span>
                      </div>
                      <p className="text-sm md:text-base text-gray-800 font-medium">{formatTimeAgo(selectedAlert.timestamp)}</p>
                    </div>
                  </div>

                  {/* Description */}
                  <div>
                    <h3 className="text-base md:text-lg font-semibold text-gray-800 mb-3">Description</h3>
                    <p className="text-sm md:text-base text-gray-600 leading-relaxed">{selectedAlert.description}</p>
                  </div>

                  {/* Impact Information */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <h4 className="text-sm md:text-base font-semibold text-blue-800 mb-2">Affected Area</h4>
                      <p className="text-sm md:text-base text-blue-700">{selectedAlert.affectedArea}</p>
                    </div>
                    
                    <div className="bg-orange-50 border border-orange-200 rounded-lg p-4">
                      <h4 className="text-sm md:text-base font-semibold text-orange-800 mb-2">Estimated Impact</h4>
                      <p className="text-sm md:text-base text-orange-700">{selectedAlert.estimatedImpact}</p>
                    </div>
                  </div>

                  {/* Source */}
                  <div>
                    <h4 className="text-base md:text-lg font-semibold text-gray-800 mb-2">Source</h4>
                    <p className="text-sm md:text-base text-gray-600 mb-2">{selectedAlert.source}</p>
                    {selectedAlert.sourceLink !== '#' && (
                      <a
                        href={selectedAlert.sourceLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-medium text-sm md:text-base"
                      >
                        <ExternalLink className="h-4 w-4" />
                        <span>View Official Source</span>
                      </a>
                    )}
                  </div>

                  {/* Recommendations */}
                  <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                    <h4 className="text-base md:text-lg font-semibold text-green-800 mb-3">Recommended Actions</h4>
                    <ul className="text-green-700 space-y-2 text-sm md:text-base">
                      {selectedAlert.severity === 'critical' && (
                        <>
                          <li>• Avoid the affected area immediately</li>
                          <li>• Seek immediate medical attention if experiencing symptoms</li>
                          <li>• Follow all official evacuation or safety orders</li>
                        </>
                      )}
                      {selectedAlert.severity === 'high' && (
                        <>
                          <li>• Exercise extreme caution in the affected area</li>
                          <li>• Monitor symptoms and seek medical care if needed</li>
                          <li>• Follow local health authority guidelines</li>
                        </>
                      )}
                      {(selectedAlert.severity === 'medium' || selectedAlert.severity === 'low') && (
                        <>
                          <li>• Stay informed about the situation</li>
                          <li>• Take preventive measures as recommended</li>
                          <li>• Monitor for updates from health authorities</li>
                        </>
                      )}
                      <li>• Share this information with family and friends</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="p-4 md:p-6 border-t border-gray-200">
                <p className="text-xs text-gray-500 text-center">
                  Last updated: {new Date(selectedAlert.timestamp).toLocaleString()}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default LiveAlertsPage;
import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import { AlertTriangle, Calendar, MapPin, ExternalLink, X } from 'lucide-react';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

// Custom icon for disease markers
const diseaseIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
  shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41]
});

interface DiseaseReport {
  id: string;
  disease: string;
  location: string;
  lat: number;
  lng: number;
  dateReported: string;
  source: string;
  sourceLink: string;
  summary: string;
  severity: 'low' | 'medium' | 'high';
  cases: number;
}

const mockReports: DiseaseReport[] = [
  {
    id: '1',
    disease: 'Flu Outbreak',
    location: 'Manhattan, NY',
    lat: 18.5178,
    lng: 73.8151,
    dateReported: '2024-01-15',
    source: 'NYC Health Department',
    sourceLink: 'https://www1.nyc.gov/site/doh/health/health-topics/flu.page',
    summary: 'Seasonal flu outbreak reported in Manhattan area with increased hospital admissions.',
    severity: 'medium',
    cases: 150
  },
  {
    id: '2',
    disease: 'Food Poisoning',
    location: 'Brooklyn, NY',
    lat: 40.6782,
    lng: -73.9442,
    dateReported: '2024-01-18',
    source: 'CDC',
    sourceLink: 'https://www.cdc.gov/foodsafety/',
    summary: 'Multiple cases of food poisoning linked to a local restaurant chain.',
    severity: 'high',
    cases: 45
  },
  {
    id: '3',
    disease: 'Respiratory Illness',
    location: 'Queens, NY',
    lat: 40.7282,
    lng: -73.7949,
    dateReported: '2024-01-20',
    source: 'WHO',
    sourceLink: 'https://www.who.int/',
    summary: 'Cluster of respiratory illness cases reported in Queens area.',
    severity: 'low',
    cases: 25
  },
  {
    id: '4',
    disease: 'Skin Infection',
    location: 'Bronx, NY',
    lat: 40.8448,
    lng: -73.8648,
    dateReported: '2024-01-22',
    source: 'Local Hospital',
    sourceLink: '#',
    summary: 'Increase in skin infection cases, possibly linked to contaminated water source.',
    severity: 'medium',
    cases: 30
  }
];

const DiseaseMapPage: React.FC = () => {
  const [reports, setReports] = useState<DiseaseReport[]>(mockReports);
  const [selectedReport, setSelectedReport] = useState<DiseaseReport | null>(null);
  const [isDrawerOpen, setIsDrawerOpen] = useState(false);
  const [mapCenter] = useState<[number, number]>([40.7128, -74.0060]);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'text-red-600 bg-red-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'low': return 'text-green-600 bg-green-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  const getSeverityIcon = (severity: string) => {
    const iconColor = severity === 'high' ? 'red' : severity === 'medium' ? 'orange' : 'green';
    return new L.Icon({
      iconUrl: `https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-${iconColor}.png`,
      shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
      iconSize: [25, 41],
      iconAnchor: [12, 41],
      popupAnchor: [1, -34],
      shadowSize: [41, 41]
    });
  };

  const handleMarkerClick = (report: DiseaseReport) => {
    setSelectedReport(report);
    setIsDrawerOpen(true);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  return (
    <div className="min-h-screen bg-gray-50 relative pt-16">
      <div className="max-w-7xl mx-auto p-2 md:p-4 lg:p-6">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-md p-4 md:p-6 mb-4 md:mb-6">
          <div className="flex items-center space-x-3 mb-4">
            <AlertTriangle className="h-8 w-8 text-red-600" />
            <div>
              <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-800">Disease Outbreak Map</h1>
              <p className="text-sm md:text-base text-gray-600">Real-time tracking of health incidents and outbreaks</p>
            </div>
          </div>
          
          <div className="flex flex-wrap gap-2 md:gap-4 text-xs md:text-sm">
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-red-500 rounded-full"></div>
              <span>High Severity</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-yellow-500 rounded-full"></div>
              <span>Medium Severity</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-green-500 rounded-full"></div>
              <span>Low Severity</span>
            </div>
          </div>
        </div>

        {/* Map Container */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="h-80 md:h-96 lg:h-[600px]">
            <MapContainer
              center={mapCenter}
              zoom={11}
              style={{ height: '100%', width: '100%' }}
            >
              <TileLayer
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
              />
              
              {reports.map((report) => (
                <Marker
                  key={report.id}
                  position={[report.lat, report.lng]}
                  icon={getSeverityIcon(report.severity)}
                  eventHandlers={{
                    click: () => handleMarkerClick(report)
                  }}
                >
                  <Popup>
                    <div className="p-2 min-w-48 md:min-w-64">
                      <div className="flex items-start justify-between mb-2">
                        <h3 className="font-semibold text-gray-800 text-sm md:text-base">{report.disease}</h3>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getSeverityColor(report.severity)}`}>
                          {report.severity.toUpperCase()}
                        </span>
                      </div>
                      
                      <div className="space-y-2 text-xs md:text-sm">
                        <div className="flex items-center space-x-2 text-gray-600">
                          <MapPin className="h-4 w-4" />
                          <span className="truncate">{report.location}</span>
                        </div>
                        
                        <div className="flex items-center space-x-2 text-gray-600">
                          <Calendar className="h-4 w-4" />
                          <span>{formatDate(report.dateReported)}</span>
                        </div>
                        
                        <p className="text-gray-700 text-xs md:text-sm">{report.summary}</p>
                        <p className="font-medium text-red-600">{report.cases} reported cases</p>
                      </div>
                      
                      <button
                        onClick={() => handleMarkerClick(report)}
                        className="w-full mt-3 bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded text-xs md:text-sm transition-colors duration-200"
                      >
                        View Details
                      </button>
                    </div>
                  </Popup>
                </Marker>
              ))}
            </MapContainer>
          </div>
        </div>
      </div>

      {/* Side Drawer */}
      {isDrawerOpen && selectedReport && (
        <div className="fixed inset-0 z-50 overflow-hidden">
          <div className="absolute inset-0 bg-black bg-opacity-50" onClick={() => setIsDrawerOpen(false)}></div>
          
          <div className="absolute right-0 top-0 h-full w-full md:max-w-lg bg-white shadow-xl transform transition-transform duration-300 ease-in-out">
            <div className="flex flex-col h-full">
              {/* Header */}
              <div className="flex items-center justify-between p-4 md:p-6 border-b border-gray-200">
                <h2 className="text-lg md:text-xl font-bold text-gray-800">Outbreak Details</h2>
                <button
                  onClick={() => setIsDrawerOpen(false)}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors duration-200"
                >
                  <X className="h-5 w-5 text-gray-500" />
                </button>
              </div>

              {/* Content */}
              <div className="flex-1 overflow-y-auto p-4 md:p-6">
                <div className="space-y-4 md:space-y-6">
                  {/* Disease Info */}
                  <div>
                    <div className="flex flex-col md:flex-row items-start md:items-center justify-between mb-3 space-y-2 md:space-y-0">
                      <h3 className="text-xl md:text-2xl font-bold text-gray-800">{selectedReport.disease}</h3>
                      <span className={`px-3 py-1 rounded-full text-sm md:text-base font-medium ${getSeverityColor(selectedReport.severity)}`}>
                        {selectedReport.severity.toUpperCase()} RISK
                      </span>
                    </div>
                    
                    <div className="bg-red-50 border border-red-200 rounded-lg p-4 mb-4">
                      <div className="flex items-center space-x-2 text-red-700">
                        <AlertTriangle className="h-5 w-5" />
                        <span className="font-medium text-base md:text-lg">{selectedReport.cases} Reported Cases</span>
                      </div>
                    </div>
                  </div>

                  {/* Location & Date */}
                  <div className="grid grid-cols-1 gap-4">
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center space-x-2 text-gray-600 mb-2">
                        <MapPin className="h-5 w-5" />
                        <span className="text-sm md:text-base font-medium">Location</span>
                      </div>
                      <p className="text-sm md:text-base text-gray-800 font-medium">{selectedReport.location}</p>
                    </div>
                    
                    <div className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center space-x-2 text-gray-600 mb-2">
                        <Calendar className="h-5 w-5" />
                        <span className="text-sm md:text-base font-medium">Date Reported</span>
                      </div>
                      <p className="text-sm md:text-base text-gray-800 font-medium">{formatDate(selectedReport.dateReported)}</p>
                    </div>
                  </div>

                  {/* Summary */}
                  <div>
                    <h4 className="text-base md:text-lg font-semibold text-gray-800 mb-2">Summary</h4>
                    <p className="text-sm md:text-base text-gray-600 leading-relaxed">{selectedReport.summary}</p>
                  </div>

                  {/* Source */}
                  <div>
                    <h4 className="text-base md:text-lg font-semibold text-gray-800 mb-2">Source</h4>
                    <p className="text-sm md:text-base text-gray-600 mb-2">{selectedReport.source}</p>
                    {selectedReport.sourceLink !== '#' && (
                      <a
                        href={selectedReport.sourceLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="inline-flex items-center space-x-2 text-blue-600 hover:text-blue-700 font-medium text-sm md:text-base"
                      >
                        <ExternalLink className="h-4 w-4" />
                        <span>View Source</span>
                      </a>
                    )}
                  </div>

                  {/* Safety Information */}
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                    <h4 className="text-base md:text-lg font-semibold text-blue-800 mb-2">Safety Recommendations</h4>
                    <ul className="text-blue-700 space-y-1 text-sm md:text-base">
                      <li>• Avoid affected areas if possible</li>
                      <li>• Follow local health authority guidelines</li>
                      <li>• Seek medical attention if symptoms develop</li>
                      <li>• Maintain good hygiene practices</li>
                    </ul>
                  </div>
                </div>
              </div>

              {/* Footer */}
              <div className="p-4 md:p-6 border-t border-gray-200">
                <p className="text-xs text-gray-500 text-center">
                  Last updated: {new Date().toLocaleString()}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default DiseaseMapPage;
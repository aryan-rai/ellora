import React, { useState, useRef, useEffect } from 'react';
import { Send, Upload, FileText, Image, Loader } from 'lucide-react';
import axios from 'axios';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
}

interface UploadedFile {
  name: string;
  type: string;
  size: number;
}

const ChatbotPage: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      text: 'Hello! I\'m your AI Doctor assistant. I can help you understand medical conditions, analyze symptoms, and provide general health advice. Describe your symptoms to get started.',
      sender: 'ai',
      timestamp: new Date()
    }
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async () => {
    if (!inputText.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      text: inputText,
      sender: 'user',
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const messageText = inputText;
    setInputText('');
    setIsLoading(true);

    try {
      // Build conversation history for context
      const conversationHistory = messages.map(msg => ({
        role: msg.sender === 'user' ? 'user' : 'assistant',
        content: msg.text
      }));

      // Add the current user message
      conversationHistory.push({
        role: 'user',
        content: messageText
      });

      // Keep only the last 10 messages for context (to avoid token limits)
      const recentHistory = conversationHistory.slice(-10);

      // Call OpenAI API with the provided credentials
      const response = await axios.post('https://api.openai.com/v1/chat/completions', {
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: 'You are an AI Doctor assistant. You can help users understand medical conditions, analyze symptoms, and provide general health advice. Always remind users that you cannot replace professional medical consultation and they should seek immediate medical attention for serious symptoms. Be empathetic, professional, and provide helpful health information based on medical knowledge.'
          },
          ...recentHistory
        ],
        max_tokens: 500,
        temperature: 0.7
      }, {
        headers: {
          'Authorization': 'Bearer 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',
          'Content-Type': 'application/json'
        }
      });

      const aiResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: response.data.choices[0].message.content,
        sender: 'ai',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, aiResponse]);
    } catch (error) {
      console.error('API Error:', error);
      
      // Fallback response if API fails
      const fallbackResponse: Message = {
        id: (Date.now() + 1).toString(),
        text: 'I apologize, but I\'m having trouble connecting to my AI services right now. Please try again in a moment. If the issue persists, I recommend consulting with a healthcare professional for your health concerns.',
        sender: 'ai',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, fallbackResponse]);
    } finally {
      setIsLoading(false);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      const newFiles: UploadedFile[] = Array.from(files).map(file => ({
        name: file.name,
        type: file.type,
        size: file.size
      }));
      
      setUploadedFiles(prev => [...prev, ...newFiles]);
      
      // Add a message about the uploaded file
      const fileMessage: Message = {
        id: Date.now().toString(),
        text: `I've uploaded ${newFiles.length} file(s): ${newFiles.map(f => f.name).join(', ')}. Please analyze these medical reports.`,
        sender: 'user',
        timestamp: new Date()
      };
      
      setMessages(prev => [...prev, fileMessage]);
      
      // AI response for file upload
      setTimeout(() => {
        const aiResponse: Message = {
          id: (Date.now() + 1).toString(),
          text: 'Thank you for uploading your medical reports. I can see the files you\'ve shared. While I can provide general insights, please remember that I cannot replace a consultation with your healthcare provider. Based on what you\'ve shared, could you tell me more about any specific symptoms or concerns you\'d like me to help you understand?',
          sender: 'ai',
          timestamp: new Date()
        };
        setMessages(prev => [...prev, aiResponse]);
      }, 1000);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 p-2 md:p-4 lg:p-6 pt-20">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-lg md:rounded-2xl shadow-xl overflow-hidden" style={{ height: 'calc(100vh - 100px)' }}>
          <div className="flex flex-col md:flex-row h-full">
            {/* Left Panel - File Upload */}
            <div className="md:w-1/3 lg:w-1/4 xl:w-1/3 border-b md:border-b-0 md:border-r border-gray-200 p-3 md:p-4 lg:p-6 flex flex-col">
              <h2 className="text-lg md:text-xl font-bold text-gray-800 mb-4">Medical Reports</h2>
              
              <div 
                className="flex-1 border-2 border-dashed border-gray-300 rounded-lg p-3 md:p-4 lg:p-6 flex flex-col items-center justify-center cursor-pointer hover:border-blue-400 hover:bg-blue-50 transition-all duration-200 min-h-32 md:min-h-0"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="h-8 md:h-10 lg:h-12 w-8 md:w-10 lg:w-12 text-gray-400 mb-2 md:mb-4" />
                <p className="text-sm md:text-base text-gray-600 text-center mb-2">
                  Drag and drop your medical reports here
                </p>
                <p className="text-xs md:text-sm text-gray-500 text-center mb-2 md:mb-4">
                  Supports PDF, JPG, PNG files
                </p>
                <button className="bg-blue-600 hover:bg-blue-700 text-white px-3 md:px-4 py-2 rounded-lg transition-colors duration-200 text-sm md:text-base">
                  Browse Files
                </button>
              </div>

              <input
                ref={fileInputRef}
                type="file"
                multiple
                accept=".pdf,.jpg,.jpeg,.png"
                onChange={handleFileUpload}
                className="hidden"
              />

              {uploadedFiles.length > 0 && (
                <div className="mt-4 md:mt-6">
                  <h3 className="font-semibold text-gray-700 mb-3">Uploaded Files</h3>
                  <div className="space-y-2">
                    {uploadedFiles.map((file, index) => (
                      <div key={index} className="flex items-center p-2 md:p-3 bg-gray-50 rounded-lg">
                        {file.type.includes('pdf') ? (
                          <FileText className="h-5 w-5 text-red-500 mr-3" />
                        ) : (
                          <Image className="h-5 w-5 text-blue-500 mr-3" />
                        )}
                        <div className="flex-1">
                          <p className="text-xs md:text-sm font-medium text-gray-700 truncate">{file.name}</p>
                          <p className="text-xs text-gray-500">{formatFileSize(file.size)}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Right Panel - Chat */}
            <div className="flex-1 flex flex-col">
              {/* Chat Header */}
              <div className="p-3 md:p-4 lg:p-6 border-b border-gray-200 bg-gradient-to-r from-blue-600 to-green-500">
                <div className="flex items-center space-x-3">
                  <img 
                    src="/ellora_logo1.png" 
                    alt="Ellora AI" 
                    className="h-6 md:h-8 w-auto brightness-0 invert"
                  />
                  <div>
                    <h1 className="text-lg md:text-xl lg:text-2xl font-bold text-white">Ellora AI Doctor</h1>
                  </div>
                </div>
                <p className="text-blue-100 text-sm md:text-base">Get instant medical advice and insights</p>
              </div>

              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-3 md:p-4 lg:p-6 space-y-4">
                {messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-xs lg:max-w-md px-4 py-3 rounded-2xl ${
                        message.sender === 'user'
                          ? 'bg-blue-600 text-white rounded-br-none'
                          : 'bg-gray-100 text-gray-800 rounded-bl-none'
                      }`}
                    >
                      <p className="text-sm md:text-base whitespace-pre-wrap">{message.text}</p>
                      <p className={`text-xs mt-2 ${
                        message.sender === 'user' ? 'text-blue-200' : 'text-gray-500'
                      }`}>
                        {message.timestamp.toLocaleTimeString()}
                      </p>
                    </div>
                  </div>
                ))}
                
                {isLoading && (
                  <div className="flex justify-start">
                    <div className="bg-gray-100 rounded-2xl rounded-bl-none p-4">
                      <Loader className="h-5 w-5 animate-spin text-gray-500" />
                    </div>
                  </div>
                )}
                
                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className="p-3 md:p-4 lg:p-6 border-t border-gray-200">
                <div className="flex flex-col md:flex-row space-y-2 md:space-y-0 md:space-x-4">
                  <div className="flex-1 relative">
                    <textarea
                      value={inputText}
                      onChange={(e) => setInputText(e.target.value)}
                      onKeyPress={handleKeyPress}
                      placeholder="Describe your symptoms or ask a medical question..."
                      rows={window.innerWidth < 768 ? 2 : 3}
                      className="w-full px-3 md:px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none text-sm md:text-base"
                      disabled={isLoading}
                    />
                  </div>
                  <button
                    onClick={handleSendMessage}
                    disabled={!inputText.trim() || isLoading}
                    className="bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white p-2 md:p-3 rounded-lg transition-colors duration-200 self-end md:self-auto"
                  >
                    <Send className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ChatbotPage;
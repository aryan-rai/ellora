import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { 
  Shield, 
  Plus, 
  Edit, 
  Trash2, 
  Save, 
  X, 
  Globe, 
  AlertTriangle, 
  MapPin,
  Calendar,
  Eye,
  EyeOff,
  ExternalLink,
  Users,
  Activity,
  TrendingUp,
  Database,
  Settings,
  BarChart3
} from 'lucide-react';

interface AdminUser {
  id: string;
  role: string;
  permissions: {
    manage_alerts: boolean;
    manage_articles: boolean;
  };
}

interface HealthArticle {
  id?: string;
  title: string;
  summary: string;
  content: string;
  author: string;
  publication: string;
  category: string;
  image_url: string;
  source_url: string;
  tags: string[];
  is_breaking: boolean;
  is_published: boolean;
}

interface HealthAlert {
  id?: string;
  title: string;
  description: string;
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info';
  category: string;
  location: string;
  affected_area: string;
  estimated_impact: string;
  source: string;
  source_link: string;
  is_active: boolean;
}

interface DiseaseLocation {
  id?: string;
  disease: string;
  location: string;
  lat: number;
  lng: number;
  cases: number;
  severity: 'low' | 'medium' | 'high';
  summary: string;
  source: string;
  source_link: string;
}

const AdminDashboard: React.FC = () => {
  const { user } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');
  const [message, setMessage] = useState('');

  // Articles state
  const [articles, setArticles] = useState<HealthArticle[]>([]);
  const [showAddArticle, setShowAddArticle] = useState(false);
  const [editingArticle, setEditingArticle] = useState<HealthArticle | null>(null);

  // Alerts state
  const [alerts, setAlerts] = useState<HealthAlert[]>([]);
  const [showAddAlert, setShowAddAlert] = useState(false);
  const [editingAlert, setEditingAlert] = useState<HealthAlert | null>(null);

  // Disease locations state (for future implementation)
  const [diseaseLocations, setDiseaseLocations] = useState<DiseaseLocation[]>([]);

  // User management state
  const [users, setUsers] = useState<any[]>([]);
  const [totalUsers, setTotalUsers] = useState(0);
  const [totalProfiles, setTotalProfiles] = useState(0);

  useEffect(() => {
    if (user) {
      checkAdminStatus();
    } else {
      setIsLoading(false);
      setIsAdmin(false);
    }
  }, [user]);

  useEffect(() => {
    if (isAdmin) {
      fetchData();
      fetchUserStats();
    }
  }, [isAdmin]);

  const checkAdminStatus = async () => {
    if (!user) return;

    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('admin_users')
        .select('*')
        .eq('id', user.id)
        .maybeSingle();

      if (error) {
        console.error('Admin check error:', error);
        setIsAdmin(false);
      } else {
        setIsAdmin(true);
      }
    } catch (error) {
      console.error('Admin check catch error:', error);
      setIsAdmin(false);
    } finally {
      setIsLoading(false);
    }
  };

  const fetchData = async () => {
    if (!isAdmin) return;
    
    try {
      // Fetch articles
      const { data: articlesData, error: articlesError } = await supabase
        .from('health_articles')
        .select('*')
        .order('created_at', { ascending: false });

      if (articlesError) {
        console.error('Error fetching articles:', articlesError);
      } else if (articlesData) {
        setArticles(articlesData);
      }

      // Fetch alerts
      const { data: alertsData, error: alertsError } = await supabase
        .from('health_alerts')
        .select('*')
        .order('created_at', { ascending: false });

      if (alertsError) {
        console.error('Error fetching alerts:', alertsError);
      } else if (alertsData) {
        setAlerts(alertsData);
      }
    } catch (error) {
      console.error('Error fetching admin data:', error);
    }
  };

  const fetchUserStats = async () => {
    try {
      // Get total users count
      const { count: usersCount, error: usersError } = await supabase
        .from('profiles')
        .select('*', { count: 'exact', head: true });

      if (!usersError) {
        setTotalUsers(usersCount || 0);
      }

      // Get total profiles count
      const { count: profilesCount, error: profilesError } = await supabase
        .from('user_profiles')
        .select('*', { count: 'exact', head: true });

      if (!profilesError) {
        setTotalProfiles(profilesCount || 0);
      }

      // Get recent users
      const { data: recentUsers, error: recentUsersError } = await supabase
        .from('profiles')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);

      if (!recentUsersError && recentUsers) {
        setUsers(recentUsers);
      }
    } catch (error) {
      console.error('Error fetching user stats:', error);
    }
  };

  const saveArticle = async (articleData: HealthArticle) => {
    try {
      setIsLoading(true);
      setMessage('');
      
      const articleToSave = {
        ...articleData,
        created_by: user?.id,
        tags: Array.isArray(articleData.tags) ? articleData.tags : articleData.tags.toString().split(',').map(t => t.trim())
      };

      let error;
      if (articleData.id) {
        // Update existing article
        const result = await supabase
          .from('health_articles')
          .update(articleToSave)
          .eq('id', articleData.id);
        error = result.error;
      } else {
        // Create new article
        const result = await supabase
          .from('health_articles')
          .insert(articleToSave);
        error = result.error;
      }

      if (error) {
        console.error('Error saving article:', error);
        setMessage('Error saving article: ' + error.message);
      } else {
        setMessage(articleData.id ? 'Article updated successfully!' : 'Article created successfully!');
        setShowAddArticle(false);
        setEditingArticle(null);
        await fetchData();
      }
    } catch (error) {
      console.error('Error saving article:', error);
      setMessage('Error saving article');
    } finally {
      setIsLoading(false);
      setTimeout(() => setMessage(''), 3000);
    }
  };

  const saveAlert = async (alertData: HealthAlert) => {
    try {
      setIsLoading(true);
      setMessage('');
      
      const alertToSave = {
        ...alertData,
        created_by: user?.id
      };

      let error;
      if (alertData.id) {
        // Update existing alert
        const result = await supabase
          .from('health_alerts')
          .update(alertToSave)
          .eq('id', alertData.id);
        error = result.error;
      } else {
        // Create new alert
        const result = await supabase
          .from('health_alerts')
          .insert(alertToSave);
        error = result.error;
      }

      if (error) {
        console.error('Error saving alert:', error);
        setMessage('Error saving alert: ' + error.message);
      } else {
        setMessage(alertData.id ? 'Alert updated successfully!' : 'Alert created successfully!');
        setShowAddAlert(false);
        setEditingAlert(null);
        await fetchData();
      }
    } catch (error) {
      console.error('Error saving alert:', error);
      setMessage('Error saving alert');
    } finally {
      setIsLoading(false);
      setTimeout(() => setMessage(''), 3000);
    }
  };

  const deleteArticle = async (id: string) => {
    if (!confirm('Are you sure you want to delete this article?')) return;

    try {
      setMessage('');
      const { error } = await supabase
        .from('health_articles')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting article:', error);
        setMessage('Error deleting article: ' + error.message);
      } else {
        setMessage('Article deleted successfully!');
        await fetchData();
      }
    } catch (error) {
      console.error('Error deleting article:', error);
      setMessage('Error deleting article');
    } finally {
      setTimeout(() => setMessage(''), 3000);
    }
  };

  const deleteAlert = async (id: string) => {
    if (!confirm('Are you sure you want to delete this alert?')) return;

    try {
      setMessage('');
      const { error } = await supabase
        .from('health_alerts')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('Error deleting alert:', error);
        setMessage('Error deleting alert: ' + error.message);
      } else {
        setMessage('Alert deleted successfully!');
        await fetchData();
      }
    } catch (error) {
      console.error('Error deleting alert:', error);
      setMessage('Error deleting alert');
    } finally {
      setTimeout(() => setMessage(''), 3000);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center pt-16">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-purple-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Checking admin access...</p>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center pt-16">
        <div className="text-center max-w-md mx-auto p-8">
          <div className="bg-red-100 rounded-full p-4 w-20 h-20 mx-auto mb-6 flex items-center justify-center">
            <Shield className="h-10 w-10 text-red-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-3">Access Denied</h1>
          <p className="text-gray-600 mb-6">You don't have admin privileges to access this panel.</p>
          <p className="text-sm text-gray-500">Contact your system administrator if you believe this is an error.</p>
        </div>
      </div>
    );
  }

  const tabs = [
    { id: 'overview', name: 'Overview', icon: BarChart3, count: null },
    { id: 'articles', name: 'Health Articles', icon: Globe, count: articles.length },
    { id: 'alerts', name: 'Live Alerts', icon: AlertTriangle, count: alerts.length },
    { id: 'users', name: 'User Management', icon: Users, count: totalUsers },
    { id: 'settings', name: 'Settings', icon: Settings, count: null },
  ];

  const renderArticleForm = (article?: HealthArticle) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-screen overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800">
              {article ? 'Edit Article' : 'Add New Article'}
            </h2>
            <button
              onClick={() => {
                setShowAddArticle(false);
                setEditingArticle(null);
              }}
              className="text-gray-500 hover:text-gray-700"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            const articleData: HealthArticle = {
              id: article?.id,
              title: formData.get('title') as string,
              summary: formData.get('summary') as string,
              content: formData.get('content') as string,
              author: formData.get('author') as string,
              publication: formData.get('publication') as string,
              category: formData.get('category') as string,
              image_url: formData.get('image_url') as string,
              source_url: formData.get('source_url') as string,
              tags: (formData.get('tags') as string).split(',').map(t => t.trim()),
              is_breaking: formData.get('is_breaking') === 'on',
              is_published: formData.get('is_published') === 'on',
            };
            saveArticle(articleData);
          }}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                <input
                  type="text"
                  name="title"
                  defaultValue={article?.title || ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Summary</label>
                <textarea
                  name="summary"
                  rows={3}
                  defaultValue={article?.summary || ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-gray-700 mb-2">Content</label>
                <textarea
                  name="content"
                  rows={8}
                  defaultValue={article?.content || ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Author</label>
                <input
                  type="text"
                  name="author"
                  defaultValue={article?.author || ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Publication</label>
                <input
                  type="text"
                  name="publication"
                  defaultValue={article?.publication || ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                <select
                  name="category"
                  defaultValue={article?.category || ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                >
                  <option value="">Select Category</option>
                  <option value="Breaking News">Breaking News</option>
                  <option value="Research">Research</option>
                  <option value="Global Health">Global Health</option>
                  <option value="Nutrition">Nutrition</option>
                  <option value="Mental Health">Mental Health</option>
                  <option value="Disease Prevention">Disease Prevention</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Image URL</label>
                <input
                  type="url"
                  name="image_url"
                  defaultValue={article?.image_url || ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Source URL</label>
                <input
                  type="url"
                  name="source_url"
                  defaultValue={article?.source_url || ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Tags (comma-separated)</label>
                <input
                  type="text"
                  name="tags"
                  defaultValue={Array.isArray(article?.tags) ? article.tags.join(', ') : ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="covid-19, research, vaccine"
                />
              </div>

              <div className="md:col-span-2 flex items-center space-x-6">
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    name="is_breaking"
                    defaultChecked={article?.is_breaking || false}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Breaking News</span>
                </label>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    name="is_published"
                    defaultChecked={article?.is_published !== false}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Published</span>
                </label>
              </div>
            </div>

            <div className="mt-6 flex justify-end space-x-4">
              <button
                type="button"
                onClick={() => {
                  setShowAddArticle(false);
                  setEditingArticle(null);
                }}
                className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white rounded-lg flex items-center space-x-2"
              >
                <Save className="h-5 w-5" />
                <span>{isLoading ? 'Saving...' : 'Save Article'}</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );

  const renderAlertForm = (alert?: HealthAlert) => (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-screen overflow-y-auto">
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-2xl font-bold text-gray-800">
              {alert ? 'Edit Alert' : 'Add New Alert'}
            </h2>
            <button
              onClick={() => {
                setShowAddAlert(false);
                setEditingAlert(null);
              }}
              className="text-gray-500 hover:text-gray-700"
            >
              <X className="h-6 w-6" />
            </button>
          </div>

          <form onSubmit={(e) => {
            e.preventDefault();
            const formData = new FormData(e.currentTarget);
            const alertData: HealthAlert = {
              id: alert?.id,
              title: formData.get('title') as string,
              description: formData.get('description') as string,
              severity: formData.get('severity') as 'critical' | 'high' | 'medium' | 'low' | 'info',
              category: formData.get('category') as string,
              location: formData.get('location') as string,
              affected_area: formData.get('affected_area') as string,
              estimated_impact: formData.get('estimated_impact') as string,
              source: formData.get('source') as string,
              source_link: formData.get('source_link') as string,
              is_active: formData.get('is_active') === 'on',
            };
            saveAlert(alertData);
          }}>
            <div className="grid grid-cols-1 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Title</label>
                <input
                  type="text"
                  name="title"
                  defaultValue={alert?.title || ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Description</label>
                <textarea
                  name="description"
                  rows={4}
                  defaultValue={alert?.description || ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Severity</label>
                  <select
                    name="severity"
                    defaultValue={alert?.severity || ''}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  >
                    <option value="">Select Severity</option>
                    <option value="critical">Critical</option>
                    <option value="high">High</option>
                    <option value="medium">Medium</option>
                    <option value="low">Low</option>
                    <option value="info">Info</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Category</label>
                  <select
                    name="category"
                    defaultValue={alert?.category || ''}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  >
                    <option value="">Select Category</option>
                    <option value="Disease Outbreak">Disease Outbreak</option>
                    <option value="Environmental">Environmental</option>
                    <option value="Food Safety">Food Safety</option>
                    <option value="Weather">Weather</option>
                    <option value="Water Safety">Water Safety</option>
                    <option value="Public Health">Public Health</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Location</label>
                <input
                  type="text"
                  name="location"
                  defaultValue={alert?.location || ''}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Affected Area</label>
                  <input
                    type="text"
                    name="affected_area"
                    defaultValue={alert?.affected_area || ''}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="e.g., ~500,000 residents"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Estimated Impact</label>
                  <input
                    type="text"
                    name="estimated_impact"
                    defaultValue={alert?.estimated_impact || ''}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="e.g., High transmission risk"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Source</label>
                  <input
                    type="text"
                    name="source"
                    defaultValue={alert?.source || ''}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    required
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Source Link</label>
                  <input
                    type="url"
                    name="source_link"
                    defaultValue={alert?.source_link || ''}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>
              </div>

              <div>
                <label className="flex items-center">
                  <input
                    type="checkbox"
                    name="is_active"
                    defaultChecked={alert?.is_active !== false}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                  <span className="ml-2 text-sm text-gray-700">Active Alert</span>
                </label>
              </div>
            </div>

            <div className="mt-6 flex justify-end space-x-4">
              <button
                type="button"
                onClick={() => {
                  setShowAddAlert(false);
                  setEditingAlert(null);
                }}
                className="px-6 py-3 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={isLoading}
                className="px-6 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-blue-400 text-white rounded-lg flex items-center space-x-2"
              >
                <Save className="h-5 w-5" />
                <span>{isLoading ? 'Saving...' : 'Save Alert'}</span>
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto p-2 sm:p-4">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-md p-4 sm:p-6 mb-4 sm:mb-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <div className="bg-gradient-to-r from-purple-600 to-blue-500 p-3 rounded-xl">
                <Shield className="h-8 w-8 text-white" />
              </div>
              <div>
                <h1 className="text-xl sm:text-3xl font-bold text-gray-800">Admin Panel</h1>
                <p className="text-sm sm:text-base text-gray-600">Manage health content and alerts</p>
              </div>
            </div>
            <div className="text-right hidden sm:block">
              <p className="text-xs sm:text-sm text-gray-500">Logged in as</p>
              <p className="font-medium text-gray-800 text-sm sm:text-base truncate max-w-48">{user?.email}</p>
            </div>
          </div>

          {message && (
            <div className={`mt-4 p-4 rounded-lg text-sm ${
              message.includes('successfully') 
                ? 'bg-green-50 text-green-700 border border-green-200'
                : 'bg-red-50 text-red-700 border border-red-200'
            }`}>
              {message}
            </div>
          )}
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6 mb-4 sm:mb-6">
          <div className="bg-white rounded-lg shadow-md p-4 sm:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs sm:text-sm font-medium text-gray-600">Published Articles</p>
                <p className="text-xl sm:text-3xl font-bold text-blue-600">{articles.length}</p>
              </div>
              <Globe className="h-8 sm:h-12 w-8 sm:w-12 text-blue-500" />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-md p-4 sm:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs sm:text-sm font-medium text-gray-600">Active Alerts</p>
                <p className="text-xl sm:text-3xl font-bold text-red-600">{alerts.filter(a => a.is_active).length}</p>
              </div>
              <AlertTriangle className="h-8 sm:h-12 w-8 sm:w-12 text-red-500" />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-md p-4 sm:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs sm:text-sm font-medium text-gray-600">Total Users</p>
                <p className="text-xl sm:text-3xl font-bold text-green-600">{totalUsers}</p>
              </div>
              <Users className="h-8 sm:h-12 w-8 sm:w-12 text-green-500" />
            </div>
          </div>
          <div className="bg-white rounded-lg shadow-md p-4 sm:p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs sm:text-sm font-medium text-gray-600">Health Profiles</p>
                <p className="text-xl sm:text-3xl font-bold text-purple-600">{totalProfiles}</p>
              </div>
              <Activity className="h-8 sm:h-12 w-8 sm:w-12 text-purple-500" />
            </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="bg-white rounded-lg shadow-md mb-4 sm:mb-6">
          <div className="border-b border-gray-200">
            <nav className="flex space-x-2 sm:space-x-8 px-3 sm:px-6 overflow-x-auto">
              {tabs.map((tab) => {
                const Icon = tab.icon;
                return (
                  <button
                    key={tab.id}
                    onClick={() => setActiveTab(tab.id)}
                    className={`flex items-center space-x-1 sm:space-x-2 py-4 px-1 border-b-2 font-medium text-xs sm:text-sm whitespace-nowrap ${
                      activeTab === tab.id
                        ? 'border-purple-500 text-purple-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    }`}
                  >
                    <Icon className="h-5 w-5" />
                    <span className="hidden sm:inline">{tab.name}</span>
                    <span className="sm:hidden">{tab.name.split(' ')[0]}</span>
                    {tab.count !== null && (
                      <span className={`px-1 sm:px-2 py-1 rounded-full text-xs ${
                        activeTab === tab.id ? 'bg-purple-100 text-purple-600' : 'bg-gray-100 text-gray-600'
                      }`}>
                        {tab.count}
                      </span>
                    )}
                  </button>
                );
              })}
            </nav>
          </div>
        </div>

        {/* Tab Content */}
        <div>
          {activeTab === 'overview' && (
            <div className="space-y-4 sm:space-y-6">
              {/* Quick Actions */}
              <div className="bg-white rounded-lg shadow-md p-4 sm:p-6">
                <h2 className="text-xl sm:text-2xl font-bold text-gray-800 mb-4 sm:mb-6">Quick Actions</h2>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                  <button
                    onClick={() => {
                      setActiveTab('articles');
                      setShowAddArticle(true);
                    }}
                    className="flex items-center justify-center sm:justify-start space-x-3 p-4 bg-blue-50 hover:bg-blue-100 rounded-lg transition-colors duration-200"
                  >
                    <Plus className="h-6 w-6 text-blue-600" />
                    <span className="font-medium text-blue-800 text-sm sm:text-base">Add New Article</span>
                  </button>
                  <button
                    onClick={() => {
                      setActiveTab('alerts');
                      setShowAddAlert(true);
                    }}
                    className="flex items-center justify-center sm:justify-start space-x-3 p-4 bg-red-50 hover:bg-red-100 rounded-lg transition-colors duration-200"
                  >
                    <Plus className="h-6 w-6 text-red-600" />
                    <span className="font-medium text-red-800 text-sm sm:text-base">Create Alert</span>
                  </button>
                  <button
                    onClick={() => setActiveTab('users')}
                    className="flex items-center justify-center sm:justify-start space-x-3 p-4 bg-green-50 hover:bg-green-100 rounded-lg transition-colors duration-200"
                  >
                    <Users className="h-6 w-6 text-green-600" />
                    <span className="font-medium text-green-800 text-sm sm:text-base">Manage Users</span>
                  </button>
                </div>
              </div>

              {/* Recent Activity */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-6">
                <div className="bg-white rounded-lg shadow-md p-4 sm:p-6">
                  <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-4">Recent Articles</h3>
                  <div className="space-y-3">
                    {articles.slice(0, 5).map((article) => (
                      <div key={article.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-800 truncate text-sm sm:text-base">{article.title}</h4>
                          <p className="text-xs sm:text-sm text-gray-600">{article.category}</p>
                        </div>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          article.is_published ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                        }`}>
                          {article.is_published ? 'Published' : 'Draft'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-white rounded-lg shadow-md p-4 sm:p-6">
                  <h3 className="text-lg sm:text-xl font-bold text-gray-800 mb-4">Recent Users</h3>
                  <div className="space-y-3">
                    {users.slice(0, 5).map((user) => (
                      <div key={user.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                        <div className="flex-1">
                          <h4 className="font-medium text-gray-800 text-sm sm:text-base truncate">{user.name}</h4>
                          <p className="text-xs sm:text-sm text-gray-600 truncate">{user.email}</p>
                        </div>
                        <span className="text-xs text-gray-500">
                          {new Date(user.created_at).toLocaleDateString()}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'articles' && (
            <div className="bg-white rounded-lg shadow-md p-4 sm:p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl sm:text-2xl font-bold text-gray-800">Health Articles</h2>
                <button
                  onClick={() => setShowAddArticle(true)}
                  className="bg-blue-600 hover:bg-blue-700 text-white px-3 sm:px-4 py-2 rounded-lg flex items-center space-x-2 text-sm sm:text-base"
                >
                  <Plus className="h-5 w-5" />
                  <span className="hidden sm:inline">Add Article</span>
                  <span className="sm:hidden">Add</span>
                </button>
              </div>

              <div className="space-y-4">
                {articles.map((article) => (
                  <div key={article.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-2 mb-2">
                          <h3 className="font-semibold text-gray-800 text-sm sm:text-base">{article.title}</h3>
                          {article.is_breaking && (
                            <span className="bg-red-100 text-red-700 px-2 py-1 rounded-full text-xs font-medium">
                              BREAKING
                            </span>
                          )}
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            article.is_published ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                          }`}>
                            {article.is_published ? 'Published' : 'Draft'}
                          </span>
                        </div>
                        <p className="text-xs sm:text-sm text-gray-600 mb-2 line-clamp-2">{article.summary}</p>
                        <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-1 sm:space-y-0 sm:space-x-4 text-xs sm:text-sm text-gray-500">
                          <span>Category: {article.category}</span>
                          <span className="truncate">Author: {article.author}</span>
                          <span className="truncate">Publication: {article.publication}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 ml-2 sm:ml-4">
                        <button
                          onClick={() => setEditingArticle(article)}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          <Edit className="h-5 w-5" />
                        </button>
                        <button
                          onClick={() => deleteArticle(article.id!)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

                {articles.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Globe className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <p>No articles created yet</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'alerts' && (
            <div className="bg-white rounded-lg shadow-md p-4 sm:p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl sm:text-2xl font-bold text-gray-800">Health Alerts</h2>
                <button
                  onClick={() => setShowAddAlert(true)}
                  className="bg-red-600 hover:bg-red-700 text-white px-3 sm:px-4 py-2 rounded-lg flex items-center space-x-2 text-sm sm:text-base"
                >
                  <Plus className="h-5 w-5" />
                  <span className="hidden sm:inline">Add Alert</span>
                  <span className="sm:hidden">Add</span>
                </button>
              </div>

              <div className="space-y-4">
                {alerts.map((alert) => (
                  <div key={alert.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-2 sm:space-y-0 sm:space-x-2 mb-2">
                          <h3 className="font-semibold text-gray-800 text-sm sm:text-base">{alert.title}</h3>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            alert.severity === 'critical' ? 'bg-red-100 text-red-700' :
                            alert.severity === 'high' ? 'bg-orange-100 text-orange-700' :
                            alert.severity === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                            alert.severity === 'low' ? 'bg-blue-100 text-blue-700' :
                            'bg-green-100 text-green-700'
                          }`}>
                            {alert.severity.toUpperCase()}
                          </span>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                            alert.is_active ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-700'
                          }`}>
                            {alert.is_active ? 'Active' : 'Inactive'}
                          </span>
                        </div>
                        <p className="text-xs sm:text-sm text-gray-600 mb-2 line-clamp-2">{alert.description}</p>
                        <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-1 sm:space-y-0 sm:space-x-4 text-xs sm:text-sm text-gray-500">
                          <span>Category: {alert.category}</span>
                          <span className="truncate">Location: {alert.location}</span>
                          <span className="truncate">Source: {alert.source}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 ml-2 sm:ml-4">
                        <button
                          onClick={() => setEditingAlert(alert)}
                          className="text-blue-600 hover:text-blue-700"
                        >
                          <Edit className="h-5 w-5" />
                        </button>
                        <button
                          onClick={() => deleteAlert(alert.id!)}
                          className="text-red-600 hover:text-red-700"
                        >
                          <Trash2 className="h-5 w-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

                {alerts.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <AlertTriangle className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <p>No alerts created yet</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'users' && (
            <div className="bg-white rounded-lg shadow-md p-4 sm:p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl sm:text-2xl font-bold text-gray-800">User Management</h2>
                <div className="flex flex-col sm:flex-row items-end sm:items-center space-y-1 sm:space-y-0 sm:space-x-4">
                  <span className="text-xs sm:text-sm text-gray-600">Total Users: {totalUsers}</span>
                  <span className="text-xs sm:text-sm text-gray-600">Health Profiles: {totalProfiles}</span>
                </div>
              </div>

              <div className="space-y-4">
                {users.map((user) => (
                  <div key={user.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-800 text-sm sm:text-base truncate">{user.name}</h3>
                        <p className="text-xs sm:text-sm text-gray-600 mb-2 truncate">{user.email}</p>
                        <div className="flex flex-col sm:flex-row items-start sm:items-center space-y-1 sm:space-y-0 sm:space-x-4 text-xs sm:text-sm text-gray-500">
                          <span>Joined: {new Date(user.created_at).toLocaleDateString()}</span>
                          <span>Last Updated: {new Date(user.updated_at).toLocaleDateString()}</span>
                        </div>
                      </div>
                      <div className="flex items-center space-x-2 ml-2 sm:ml-4">
                        <span className="px-2 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-full">
                          Active
                        </span>
                      </div>
                    </div>
                  </div>
                ))}

                {users.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    <Users className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                    <p>No users found</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'settings' && (
            <div className="bg-white rounded-lg shadow-md p-4 sm:p-6">
              <h2 className="text-xl sm:text-2xl font-bold text-gray-800 mb-6">System Settings</h2>
              
              <div className="space-y-4 sm:space-y-6">
                <div className="border border-gray-200 rounded-lg p-4">
                  <h3 className="text-base sm:text-lg font-semibold text-gray-800 mb-3">Database Status</h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 sm:gap-4 text-xs sm:text-sm">
                    <div>
                      <span className="text-gray-600">Articles Table:</span>
                      <span className="ml-2 text-green-600 font-medium">✓ Connected</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Alerts Table:</span>
                      <span className="ml-2 text-green-600 font-medium">✓ Connected</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Users Table:</span>
                      <span className="ml-2 text-green-600 font-medium">✓ Connected</span>
                    </div>
                    <div>
                      <span className="text-gray-600">Profiles Table:</span>
                      <span className="ml-2 text-green-600 font-medium">✓ Connected</span>
                    </div>
                  </div>
                </div>

                <div className="border border-gray-200 rounded-lg p-4">
                  <h3 className="text-base sm:text-lg font-semibold text-gray-800 mb-3">Admin Permissions</h3>
                  <div className="space-y-2 text-xs sm:text-sm">
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Manage Articles</span>
                      <span className="text-green-600 font-medium">✓ Enabled</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">Manage Alerts</span>
                      <span className="text-green-600 font-medium">✓ Enabled</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <span className="text-gray-600">View Users</span>
                      <span className="text-green-600 font-medium">✓ Enabled</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'locations' && (
            <div className="bg-white rounded-lg shadow-md p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-800">Disease Map Locations</h2>
                <button
                  disabled
                  className="bg-gray-400 text-white px-4 py-2 rounded-lg flex items-center space-x-2 cursor-not-allowed"
                >
                  <Plus className="h-5 w-5" />
                  <span>Coming Soon</span>
                </button>
              </div>
              <div className="text-center py-8 text-gray-500">
                <MapPin className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>Disease location management will be available soon</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Modals */}
      {showAddArticle && renderArticleForm()}
      {editingArticle && renderArticleForm(editingArticle)}
      {showAddAlert && renderAlertForm()}
      {editingAlert && renderAlertForm(editingAlert)}
    </div>
  );
};

export default AdminDashboard;
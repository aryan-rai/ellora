import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { supabase } from '../lib/supabase';
import { 
  User, 
  Calendar, 
  Phone, 
  MapPin, 
  Heart, 
  Droplets, 
  Ruler, 
  Weight, 
  AlertTriangle, 
  Pill, 
  FileText, 
  Users,
  Share2,
  Copy,
  Check,
  Loader,
  Shield
} from 'lucide-react';

interface UserProfile {
  id: string;
  user_id: string;
  email: string;
  full_name: string;
  date_of_birth: string;
  gender: string;
  phone: string;
  address: string;
  city: string;
  state: string;
  zip_code: string;
  country: string;
  blood_type: string;
  height_cm: number;
  weight_kg: number;
  avatar_url: string;
  created_at: string;
}

interface MedicalCondition {
  id: string;
  condition_name: string;
  diagnosed_date: string;
  status: string;
  severity: string;
  notes: string;
}

interface Medication {
  id: string;
  medication_name: string;
  dosage: string;
  frequency: string;
  start_date: string;
  end_date: string;
  prescribed_by: string;
  purpose: string;
  is_active: boolean;
}

interface Allergy {
  id: string;
  allergen: string;
  reaction: string;
  severity: string;
  notes: string;
}

interface EmergencyContact {
  id: string;
  name: string;
  relationship: string;
  phone: string;
  email: string;
  is_primary: boolean;
}

const HealthCardPage: React.FC = () => {
  const { userId } = useParams<{ userId: string }>();
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [conditions, setConditions] = useState<MedicalCondition[]>([]);
  const [medications, setMedications] = useState<Medication[]>([]);
  const [allergies, setAllergies] = useState<Allergy[]>([]);
  const [emergencyContacts, setEmergencyContacts] = useState<EmergencyContact[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (userId) {
      fetchHealthCardData();
    }
  }, [userId]);

  const fetchHealthCardData = async () => {
    if (!userId) return;

    setIsLoading(true);
    setError('');

    try {
      console.log('Fetching health card for user:', userId);
      
      // Fetch profile
      const { data: profileData, error: profileError } = await supabase
        .from('user_profiles')
        .select('*')
        .eq('user_id', userId)
        .maybeSingle();

      console.log('Profile data:', profileData, 'Error:', profileError);

      if (profileError && profileError.code !== 'PGRST116') {
        console.error('Profile error:', profileError);
        setError('Error loading health card');
        return;
      }

      if (!profileData) {
        // Try fallback to profiles table
        const { data: fallbackProfile, error: fallbackError } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', userId)
          .maybeSingle();

        if (fallbackError || !fallbackProfile) {
          setError('Health card not found');
          return;
        }

        // Convert profiles data to user_profiles format
        const convertedProfile = {
          id: fallbackProfile.id,
          user_id: fallbackProfile.id,
          email: fallbackProfile.email,
          full_name: fallbackProfile.name || '',
          date_of_birth: '',
          gender: '',
          phone: '',
          address: '',
          city: '',
          state: '',
          zip_code: '',
          country: '',
          blood_type: '',
          height_cm: 0,
          weight_kg: 0,
          avatar_url: '',
          created_at: fallbackProfile.created_at
        };

        setProfile(convertedProfile);
      } else {
        setProfile(profileData);
      }

      // Continue with other data fetching only if we have a profile
      if (profileData || profileData) {
        if (profileError.code === 'PGRST116') {
          setError('Health card not found');
        } else {
          console.error('Profile error:', profileError);
          setError('Error loading health card');
        }
        return;
      }

      setProfile(profileData);

      // Fetch medical conditions
      const { data: conditionsData } = await supabase
        .from('medical_conditions')
        .select('*')
        .eq('user_id', userId)
        .order('diagnosed_date', { ascending: false });

      console.log('Conditions data:', conditionsData);
      if (conditionsData) {
        setConditions(conditionsData);
      }

      // Fetch active medications
      const { data: medicationsData } = await supabase
        .from('medications')
        .select('*')
        .eq('user_id', userId)
        .order('start_date', { ascending: false });

      console.log('Medications data:', medicationsData);
      if (medicationsData) {
        setMedications(medicationsData);
      }

      // Fetch allergies
      const { data: allergiesData } = await supabase
        .from('allergies')
        .select('*')
        .eq('user_id', userId);

      console.log('Allergies data:', allergiesData);
      if (allergiesData) {
        setAllergies(allergiesData);
      }

      // Fetch emergency contacts
      const { data: contactsData } = await supabase
        .from('emergency_contacts')
        .select('*')
        .eq('user_id', userId)
        .order('is_primary', { ascending: false });

      console.log('Contacts data:', contactsData);
      if (contactsData) {
        setEmergencyContacts(contactsData);
      }
    } catch (error) {
      console.error('Error fetching health card data:', error);
      setError('Error loading health card');
    } finally {
      setIsLoading(false);
    }
  };

  const copyToClipboard = async () => {
    try {
      const healthCardUrl = `${window.location.origin}/health-card/${userId}`;
      await navigator.clipboard.writeText(healthCardUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (error) {
      console.error('Failed to copy:', error);
    }
  };

  const calculateAge = (birthDate: string) => {
    const today = new Date();
    const birth = new Date(birthDate);
    let age = today.getFullYear() - birth.getFullYear();
    const monthDiff = today.getMonth() - birth.getMonth();
    
    if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < birth.getDate())) {
      age--;
    }
    
    return age;
  };

  const getSeverityColor = (severity: string) => {
    switch (severity?.toLowerCase()) {
      case 'critical':
      case 'severe':
        return 'text-red-700 bg-red-100 border-red-200';
      case 'high':
      case 'moderate':
        return 'text-orange-700 bg-orange-100 border-orange-200';
      case 'medium':
      case 'mild':
        return 'text-yellow-700 bg-yellow-100 border-yellow-200';
      case 'low':
        return 'text-green-700 bg-green-100 border-green-200';
      default:
        return 'text-gray-700 bg-gray-100 border-gray-200';
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader className="h-12 w-12 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Loading health card...</p>
        </div>
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center max-w-md mx-auto p-8">
          <div className="bg-red-100 rounded-full p-4 w-20 h-20 mx-auto mb-6 flex items-center justify-center">
            <Shield className="h-10 w-10 text-red-600" />
          </div>
          <h1 className="text-2xl font-bold text-gray-800 mb-3">Health Card Not Found</h1>
          <p className="text-gray-600 mb-6">{error || 'The requested health card could not be found.'}</p>
          <p className="text-sm text-gray-500">Please check the link and try again.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-green-50 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center space-x-4">
              <img 
                src="/ellora_logo1.png" 
                alt="Ellora AI" 
                className="h-12 w-auto"
              />
              <div>
                <h1 className="text-3xl font-bold text-gray-800">Health Card</h1>
                <p className="text-gray-600">Digital Medical Profile</p>
              </div>
            </div>
            <button
              onClick={copyToClipboard}
              className="flex items-center space-x-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors duration-200"
            >
              {copied ? <Check className="h-5 w-5" /> : <Copy className="h-5 w-5" />}
              <span>{copied ? 'Copied!' : 'Copy Link'}</span>
            </button>
          </div>

          {/* Patient Info */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-2xl font-bold text-gray-800 mb-4">{profile.full_name}</h2>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Calendar className="h-5 w-5 text-gray-500" />
                  <span className="text-gray-700">
                    {profile.date_of_birth ? `${calculateAge(profile.date_of_birth)} years old` : 'Age not specified'}
                  </span>
                </div>
                <div className="flex items-center space-x-3">
                  <User className="h-5 w-5 text-gray-500" />
                  <span className="text-gray-700">{profile.gender || 'Not specified'}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Phone className="h-5 w-5 text-gray-500" />
                  <span className="text-gray-700">{profile.phone || 'Not provided'}</span>
                </div>
                <div className="flex items-center space-x-3">
                  <MapPin className="h-5 w-5 text-gray-500" />
                  <span className="text-gray-700">
                    {profile.city && profile.state ? `${profile.city}, ${profile.state}` : 'Location not specified'}
                  </span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-red-50 border border-red-200 rounded-lg p-4 text-center">
                <Droplets className="h-8 w-8 text-red-600 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Blood Type</p>
                <p className="text-xl font-bold text-red-600">{profile.blood_type || 'Unknown'}</p>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 text-center">
                <Ruler className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Height</p>
                <p className="text-xl font-bold text-blue-600">
                  {profile.height_cm ? `${profile.height_cm} cm` : 'N/A'}
                </p>
              </div>
              <div className="bg-green-50 border border-green-200 rounded-lg p-4 text-center">
                <Weight className="h-8 w-8 text-green-600 mx-auto mb-2" />
                <p className="text-sm text-gray-600">Weight</p>
                <p className="text-xl font-bold text-green-600">
                  {profile.weight_kg ? `${profile.weight_kg} kg` : 'N/A'}
                </p>
              </div>
              <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 text-center">
                <Calendar className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                <p className="text-sm text-gray-600">DOB</p>
                <p className="text-sm font-bold text-purple-600">
                  {profile.date_of_birth ? new Date(profile.date_of_birth).toLocaleDateString() : 'N/A'}
                </p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Medical Conditions */}
          <div className="bg-white rounded-2xl shadow-xl p-6">
            <div className="flex items-center space-x-3 mb-6">
              <Heart className="h-6 w-6 text-red-600" />
              <h3 className="text-xl font-bold text-gray-800">Medical Conditions</h3>
            </div>
            
            {conditions.length > 0 ? (
              <div className="space-y-4">
                {conditions.map((condition) => (
                  <div key={condition.id} className="border border-gray-200 rounded-lg p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-gray-800">{condition.condition_name}</h4>
                      {condition.severity && (
                        <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getSeverityColor(condition.severity)}`}>
                          {condition.severity}
                        </span>
                      )}
                    </div>
                    {condition.diagnosed_date && (
                      <p className="text-sm text-gray-600 mb-2">
                        Diagnosed: {new Date(condition.diagnosed_date).toLocaleDateString()}
                      </p>
                    )}
                    {condition.notes && (
                      <p className="text-sm text-gray-700">{condition.notes}</p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Heart className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>No medical conditions recorded</p>
              </div>
            )}
          </div>

          {/* Allergies */}
          <div className="bg-white rounded-2xl shadow-xl p-6">
            <div className="flex items-center space-x-3 mb-6">
              <AlertTriangle className="h-6 w-6 text-orange-600" />
              <h3 className="text-xl font-bold text-gray-800">Allergies</h3>
            </div>
            
            {allergies.length > 0 ? (
              <div className="space-y-4">
                {allergies.map((allergy) => (
                  <div key={allergy.id} className="border border-orange-200 bg-orange-50 rounded-lg p-4">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-gray-800">{allergy.allergen}</h4>
                      {allergy.severity && (
                        <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getSeverityColor(allergy.severity)}`}>
                          {allergy.severity}
                        </span>
                      )}
                    </div>
                    {allergy.reaction && (
                      <p className="text-sm text-gray-600 mb-2">
                        <strong>Reaction:</strong> {allergy.reaction}
                      </p>
                    )}
                    {allergy.notes && (
                      <p className="text-sm text-gray-700">{allergy.notes}</p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <AlertTriangle className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>No known allergies</p>
              </div>
            )}
          </div>

          {/* Current Medications */}
          <div className="bg-white rounded-2xl shadow-xl p-6">
            <div className="flex items-center space-x-3 mb-6">
              <Pill className="h-6 w-6 text-blue-600" />
              <h3 className="text-xl font-bold text-gray-800">Current Medications</h3>
            </div>
            
            {medications.length > 0 ? (
              <div className="space-y-4">
                {medications.map((medication) => (
                  <div key={medication.id} className="border border-gray-200 rounded-lg p-4">
                    <h4 className="font-semibold text-gray-800 mb-2">{medication.medication_name}</h4>
                    <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                      {medication.dosage && (
                        <div>
                          <strong>Dosage:</strong> {medication.dosage}
                        </div>
                      )}
                      {medication.frequency && (
                        <div>
                          <strong>Frequency:</strong> {medication.frequency}
                        </div>
                      )}
                      {medication.prescribed_by && (
                        <div>
                          <strong>Prescribed by:</strong> {medication.prescribed_by}
                        </div>
                      )}
                      {medication.purpose && (
                        <div>
                          <strong>Purpose:</strong> {medication.purpose}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Pill className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>No current medications</p>
              </div>
            )}
          </div>

          {/* Emergency Contacts */}
          <div className="bg-white rounded-2xl shadow-xl p-6">
            <div className="flex items-center space-x-3 mb-6">
              <Users className="h-6 w-6 text-green-600" />
              <h3 className="text-xl font-bold text-gray-800">Emergency Contacts</h3>
            </div>
            
            {emergencyContacts.length > 0 ? (
              <div className="space-y-4">
                {emergencyContacts.map((contact) => (
                  <div key={contact.id} className={`border rounded-lg p-4 ${
                    contact.is_primary ? 'border-green-300 bg-green-50' : 'border-gray-200'
                  }`}>
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-gray-800">{contact.name}</h4>
                      {contact.is_primary && (
                        <span className="px-2 py-1 bg-green-100 text-green-700 text-xs font-medium rounded-full">
                          Primary
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-gray-600 mb-1">
                      <strong>Relationship:</strong> {contact.relationship}
                    </p>
                    <p className="text-sm text-gray-600 mb-1">
                      <strong>Phone:</strong> {contact.phone}
                    </p>
                    {contact.email && (
                      <p className="text-sm text-gray-600">
                        <strong>Email:</strong> {contact.email}
                      </p>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Users className="h-12 w-12 mx-auto mb-4 text-gray-300" />
                <p>No emergency contacts added</p>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <div className="bg-white rounded-2xl shadow-xl p-6 mt-6 text-center">
          <div className="flex items-center justify-center space-x-2 mb-4">
            <img 
              src="/ellora_logo1.png" 
              alt="Ellora AI" 
              className="h-8 w-auto"
            />
          </div>
          <p className="text-gray-600 text-sm">
            This digital health card contains confidential medical information.
          </p>
          <p className="text-gray-500 text-xs mt-2">
            Generated on {new Date().toLocaleDateString()} • Powered by Ellora AI
          </p>
        </div>
      </div>
    </div>
  );
};

export default HealthCardPage;
import React, { useState, useEffect } from 'react';
import { Calendar, Clock, MapPin, TestTube, Syringe, Home, User, Phone, Mail, Check, X, Filter, Search, Plus, ChevronLeft, ChevronRight } from 'lucide-react';

interface TestPackage {
  id: string;
  name: string;
  description: string;
  price: number;
  duration: string;
  tests: string[];
  category: 'basic' | 'comprehensive' | 'specialized';
  homeCollection: boolean;
}

interface VaccinationSchedule {
  id: string;
  vaccine: string;
  dueDate: string;
  status: 'upcoming' | 'overdue' | 'completed';
  description: string;
  ageGroup: string;
}

interface BookingSlot {
  date: string;
  time: string;
  available: boolean;
}

const testPackages: TestPackage[] = [
  {
    id: '1',
    name: 'Basic Health Checkup',
    description: 'Essential blood tests for overall health monitoring',
    price: 1200,
    duration: '2-3 hours',
    tests: ['Complete Blood Count', 'Blood Sugar', 'Cholesterol', 'Liver Function'],
    category: 'basic',
    homeCollection: true
  },
  {
    id: '2',
    name: 'Comprehensive Health Package',
    description: 'Detailed health assessment with advanced screening',
    price: 3500,
    duration: '4-5 hours',
    tests: ['CBC', 'Lipid Profile', 'Kidney Function', 'Thyroid', 'Vitamin D', 'HbA1c'],
    category: 'comprehensive',
    homeCollection: true
  },
  {
    id: '3',
    name: 'Cardiac Risk Assessment',
    description: 'Specialized tests for heart health evaluation',
    price: 2800,
    duration: '3-4 hours',
    tests: ['ECG', 'Echo', 'Stress Test', 'Cardiac Enzymes', 'Lipid Profile'],
    category: 'specialized',
    homeCollection: false
  },
  {
    id: '4',
    name: 'Diabetes Monitoring',
    description: 'Complete diabetes management panel',
    price: 1800,
    duration: '2 hours',
    tests: ['HbA1c', 'Fasting Glucose', 'Post-meal Glucose', 'Insulin Level'],
    category: 'specialized',
    homeCollection: true
  },
  {
    id: '5',
    name: 'Women\'s Health Package',
    description: 'Comprehensive health screening for women',
    price: 4200,
    duration: '4-6 hours',
    tests: ['Pap Smear', 'Mammography', 'Bone Density', 'Hormonal Panel', 'CBC'],
    category: 'comprehensive',
    homeCollection: false
  },
  {
    id: '6',
    name: 'Senior Citizen Package',
    description: 'Tailored health checkup for seniors (60+)',
    price: 3800,
    duration: '5-6 hours',
    tests: ['Complete Health Panel', 'Bone Health', 'Cognitive Assessment', 'Vision Test'],
    category: 'comprehensive',
    homeCollection: true
  }
];

const vaccinationSchedule: VaccinationSchedule[] = [
  {
    id: '1',
    vaccine: 'COVID-19 Booster',
    dueDate: '2024-02-15',
    status: 'upcoming',
    description: 'Annual COVID-19 booster shot',
    ageGroup: 'All ages'
  },
  {
    id: '2',
    vaccine: 'Influenza Vaccine',
    dueDate: '2024-01-30',
    status: 'overdue',
    description: 'Annual flu vaccination',
    ageGroup: 'All ages'
  },
  {
    id: '3',
    vaccine: 'Hepatitis B',
    dueDate: '2024-03-20',
    status: 'upcoming',
    description: 'Hepatitis B vaccination series',
    ageGroup: 'Adults'
  },
  {
    id: '4',
    vaccine: 'Tetanus Booster',
    dueDate: '2024-04-10',
    status: 'upcoming',
    description: 'Tetanus booster (every 10 years)',
    ageGroup: 'All ages'
  }
];

const TestsPage: React.FC = () => {
  const [selectedPackage, setSelectedPackage] = useState<TestPackage | null>(null);
  const [showBookingModal, setShowBookingModal] = useState(false);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [filteredPackages, setFilteredPackages] = useState(testPackages);
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedTime, setSelectedTime] = useState('');
  const [bookingForm, setBookingForm] = useState({
    name: '',
    phone: '',
    email: '',
    address: '',
    specialInstructions: ''
  });

  const categories = [
    { value: 'all', label: 'All Tests' },
    { value: 'basic', label: 'Basic' },
    { value: 'comprehensive', label: 'Comprehensive' },
    { value: 'specialized', label: 'Specialized' }
  ];

  const timeSlots = [
    '08:00 AM', '09:00 AM', '10:00 AM', '11:00 AM',
    '02:00 PM', '03:00 PM', '04:00 PM', '05:00 PM'
  ];

  useEffect(() => {
    filterPackages();
  }, [selectedCategory, searchQuery]);

  const filterPackages = () => {
    let filtered = testPackages;

    if (selectedCategory !== 'all') {
      filtered = filtered.filter(pkg => pkg.category === selectedCategory);
    }

    if (searchQuery) {
      filtered = filtered.filter(pkg =>
        pkg.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        pkg.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
        pkg.tests.some(test => test.toLowerCase().includes(searchQuery.toLowerCase()))
      );
    }

    setFilteredPackages(filtered);
  };

  const handleBooking = (pkg: TestPackage) => {
    setSelectedPackage(pkg);
    setShowBookingModal(true);
  };

  const handleBookingSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle booking submission
    console.log('Booking submitted:', {
      package: selectedPackage,
      date: selectedDate,
      time: selectedTime,
      form: bookingForm
    });
    setShowBookingModal(false);
    // Reset form
    setBookingForm({
      name: '',
      phone: '',
      email: '',
      address: '',
      specialInstructions: ''
    });
    setSelectedDate('');
    setSelectedTime('');
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case 'basic': return 'bg-green-100 text-green-700 border-green-200';
      case 'comprehensive': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'specialized': return 'bg-purple-100 text-purple-700 border-purple-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'upcoming': return 'bg-blue-100 text-blue-700 border-blue-200';
      case 'overdue': return 'bg-red-100 text-red-700 border-red-200';
      case 'completed': return 'bg-green-100 text-green-700 border-green-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const generateCalendarDays = () => {
    const year = currentDate.getFullYear();
    const month = currentDate.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startDate = new Date(firstDay);
    startDate.setDate(startDate.getDate() - firstDay.getDay());

    const days = [];
    const today = new Date();
    
    for (let i = 0; i < 42; i++) {
      const date = new Date(startDate);
      date.setDate(startDate.getDate() + i);
      
      const isCurrentMonth = date.getMonth() === month;
      const isToday = date.toDateString() === today.toDateString();
      const isPast = date < today;
      
      days.push({
        date: date,
        day: date.getDate(),
        isCurrentMonth,
        isToday,
        isPast,
        dateString: date.toISOString().split('T')[0]
      });
    }
    
    return days;
  };

  const navigateMonth = (direction: 'prev' | 'next') => {
    const newDate = new Date(currentDate);
    newDate.setMonth(currentDate.getMonth() + (direction === 'next' ? 1 : -1));
    setCurrentDate(newDate);
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-16">
      <div className="max-w-7xl mx-auto p-2 md:p-4 lg:p-6">
        {/* Header */}
        <div className="bg-white rounded-lg shadow-md p-4 md:p-6 mb-4 md:mb-6">
          <div className="flex items-center space-x-3 mb-4">
            <div className="bg-gradient-to-r from-green-600 to-blue-500 p-3 rounded-xl">
              <TestTube className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl md:text-2xl lg:text-3xl font-bold text-gray-800">Health Tests & Vaccinations</h1>
              <p className="text-sm md:text-base text-gray-600">Book blood tests with home collection and track vaccination schedule</p>
            </div>
          </div>

          {/* Search and Filter */}
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search tests, packages, or health conditions..."
                className="w-full pl-10 pr-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
              />
            </div>
            <div className="flex items-center space-x-2">
              <Filter className="h-5 w-5 text-gray-500" />
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-3 md:px-4 py-2 md:py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent text-sm md:text-base"
              >
                {categories.map((category) => (
                  <option key={category.value} value={category.value}>
                    {category.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 md:gap-6">
          {/* Test Packages */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-lg shadow-md p-4 md:p-6 mb-6">
              <h2 className="text-lg md:text-xl font-bold text-gray-800 mb-4">Available Test Packages</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {filteredPackages.map((pkg) => (
                  <div key={pkg.id} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow duration-200">
                    <div className="flex items-start justify-between mb-3">
                      <h3 className="font-semibold text-gray-800 text-sm md:text-base">{pkg.name}</h3>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getCategoryColor(pkg.category)}`}>
                        {pkg.category}
                      </span>
                    </div>
                    
                    <p className="text-gray-600 text-xs md:text-sm mb-3">{pkg.description}</p>
                    
                    <div className="space-y-2 mb-4">
                      <div className="flex items-center justify-between text-xs md:text-sm">
                        <span className="text-gray-600">Price:</span>
                        <span className="font-bold text-green-600">₹{pkg.price}</span>
                      </div>
                      <div className="flex items-center justify-between text-xs md:text-sm">
                        <span className="text-gray-600">Duration:</span>
                        <span className="text-gray-800">{pkg.duration}</span>
                      </div>
                      <div className="flex items-center justify-between text-xs md:text-sm">
                        <span className="text-gray-600">Home Collection:</span>
                        <span className={`font-medium ${pkg.homeCollection ? 'text-green-600' : 'text-orange-600'}`}>
                          {pkg.homeCollection ? 'Available' : 'Lab Visit Required'}
                        </span>
                      </div>
                    </div>

                    <div className="mb-4">
                      <p className="text-xs md:text-sm font-medium text-gray-700 mb-2">Includes:</p>
                      <div className="flex flex-wrap gap-1">
                        {pkg.tests.slice(0, 3).map((test, index) => (
                          <span key={index} className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded">
                            {test}
                          </span>
                        ))}
                        {pkg.tests.length > 3 && (
                          <span className="px-2 py-1 bg-gray-100 text-gray-600 text-xs rounded">
                            +{pkg.tests.length - 3} more
                          </span>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => handleBooking(pkg)}
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors duration-200 text-sm md:text-base"
                    >
                      Book Now
                    </button>
                  </div>
                ))}
              </div>

              {filteredPackages.length === 0 && (
                <div className="text-center py-8">
                  <TestTube className="h-12 w-12 text-gray-300 mx-auto mb-4" />
                  <p className="text-gray-500">No test packages found matching your criteria</p>
                </div>
              )}
            </div>
          </div>

          {/* Vaccination Schedule */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-lg shadow-md p-4 md:p-6 mb-6">
              <div className="flex items-center space-x-2 mb-4">
                <Syringe className="h-5 w-5 text-green-600" />
                <h2 className="text-lg md:text-xl font-bold text-gray-800">Vaccination Schedule</h2>
              </div>
              
              <div className="space-y-3">
                {vaccinationSchedule.map((vaccine) => (
                  <div key={vaccine.id} className="border border-gray-200 rounded-lg p-3">
                    <div className="flex items-start justify-between mb-2">
                      <h4 className="font-semibold text-gray-800 text-sm">{vaccine.vaccine}</h4>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(vaccine.status)}`}>
                        {vaccine.status}
                      </span>
                    </div>
                    
                    <p className="text-xs text-gray-600 mb-2">{vaccine.description}</p>
                    
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <span>Due: {formatDate(vaccine.dueDate)}</span>
                      <span>{vaccine.ageGroup}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Quick Stats */}
            <div className="bg-white rounded-lg shadow-md p-4 md:p-6">
              <h3 className="text-lg font-bold text-gray-800 mb-4">Quick Stats</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Tests Booked</span>
                  <span className="font-bold text-blue-600">12</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Upcoming Vaccines</span>
                  <span className="font-bold text-green-600">3</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Overdue Vaccines</span>
                  <span className="font-bold text-red-600">1</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Booking Modal */}
      {showBookingModal && selectedPackage && (
        <div className="fixed inset-0 z-50 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20 text-center sm:block sm:p-0">
            <div className="fixed inset-0 transition-opacity bg-gray-500 bg-opacity-75" onClick={() => setShowBookingModal(false)}></div>

            <div className="inline-block w-full max-w-4xl p-6 my-8 overflow-hidden text-left align-middle transition-all transform bg-white shadow-xl rounded-2xl">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl font-bold text-gray-800">Book Test Package</h3>
                <button
                  onClick={() => setShowBookingModal(false)}
                  className="p-2 hover:bg-gray-100 rounded-full transition-colors duration-200"
                >
                  <X className="h-5 w-5 text-gray-500" />
                </button>
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Package Details */}
                <div>
                  <div className="bg-gray-50 rounded-lg p-4 mb-6">
                    <h4 className="font-semibold text-gray-800 mb-2">{selectedPackage.name}</h4>
                    <p className="text-sm text-gray-600 mb-3">{selectedPackage.description}</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span>Price:</span>
                        <span className="font-bold text-green-600">₹{selectedPackage.price}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Duration:</span>
                        <span>{selectedPackage.duration}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Home Collection:</span>
                        <span className={selectedPackage.homeCollection ? 'text-green-600' : 'text-orange-600'}>
                          {selectedPackage.homeCollection ? 'Yes' : 'No'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Calendar */}
                  <div className="mb-6">
                    <h4 className="font-semibold text-gray-800 mb-3">Select Date</h4>
                    <div className="border border-gray-200 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-4">
                        <button
                          onClick={() => navigateMonth('prev')}
                          className="p-2 hover:bg-gray-100 rounded-full"
                        >
                          <ChevronLeft className="h-5 w-5" />
                        </button>
                        <h5 className="font-semibold">
                          {currentDate.toLocaleDateString('en-US', { month: 'long', year: 'numeric' })}
                        </h5>
                        <button
                          onClick={() => navigateMonth('next')}
                          className="p-2 hover:bg-gray-100 rounded-full"
                        >
                          <ChevronRight className="h-5 w-5" />
                        </button>
                      </div>
                      
                      <div className="grid grid-cols-7 gap-1 mb-2">
                        {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
                          <div key={day} className="text-center text-xs font-medium text-gray-500 py-2">
                            {day}
                          </div>
                        ))}
                      </div>
                      
                      <div className="grid grid-cols-7 gap-1">
                        {generateCalendarDays().map((day, index) => (
                          <button
                            key={index}
                            onClick={() => !day.isPast && day.isCurrentMonth && setSelectedDate(day.dateString)}
                            disabled={day.isPast || !day.isCurrentMonth}
                            className={`
                              p-2 text-sm rounded transition-colors duration-200
                              ${day.isCurrentMonth ? 'text-gray-800' : 'text-gray-300'}
                              ${day.isToday ? 'bg-blue-100 text-blue-600 font-bold' : ''}
                              ${selectedDate === day.dateString ? 'bg-blue-600 text-white' : ''}
                              ${day.isPast || !day.isCurrentMonth ? 'cursor-not-allowed' : 'hover:bg-blue-100'}
                            `}
                          >
                            {day.day}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Time Slots */}
                  {selectedDate && (
                    <div className="mb-6">
                      <h4 className="font-semibold text-gray-800 mb-3">Select Time</h4>
                      <div className="grid grid-cols-2 gap-2">
                        {timeSlots.map((time) => (
                          <button
                            key={time}
                            onClick={() => setSelectedTime(time)}
                            className={`
                              p-2 text-sm rounded border transition-colors duration-200
                              ${selectedTime === time 
                                ? 'bg-blue-600 text-white border-blue-600' 
                                : 'bg-white text-gray-700 border-gray-300 hover:bg-blue-50'
                              }
                            `}
                          >
                            {time}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Booking Form */}
                <div>
                  <form onSubmit={handleBookingSubmit} className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Full Name</label>
                      <input
                        type="text"
                        value={bookingForm.name}
                        onChange={(e) => setBookingForm({...bookingForm, name: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                      <input
                        type="tel"
                        value={bookingForm.phone}
                        onChange={(e) => setBookingForm({...bookingForm, phone: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Email Address</label>
                      <input
                        type="email"
                        value={bookingForm.email}
                        onChange={(e) => setBookingForm({...bookingForm, email: e.target.value})}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        required
                      />
                    </div>

                    {selectedPackage.homeCollection && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700 mb-2">Home Address</label>
                        <textarea
                          value={bookingForm.address}
                          onChange={(e) => setBookingForm({...bookingForm, address: e.target.value})}
                          rows={3}
                          className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                          required
                        />
                      </div>
                    )}

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Special Instructions (Optional)</label>
                      <textarea
                        value={bookingForm.specialInstructions}
                        onChange={(e) => setBookingForm({...bookingForm, specialInstructions: e.target.value})}
                        rows={2}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Any special requirements or instructions..."
                      />
                    </div>

                    <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                      <h5 className="font-semibold text-blue-800 mb-2">Booking Summary</h5>
                      <div className="space-y-1 text-sm text-blue-700">
                        <div>Package: {selectedPackage.name}</div>
                        <div>Date: {selectedDate ? formatDate(selectedDate) : 'Not selected'}</div>
                        <div>Time: {selectedTime || 'Not selected'}</div>
                        <div>Total: ₹{selectedPackage.price}</div>
                      </div>
                    </div>

                    <button
                      type="submit"
                      disabled={!selectedDate || !selectedTime}
                      className="w-full bg-blue-600 hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed text-white py-3 px-4 rounded-lg transition-colors duration-200 font-medium"
                    >
                      Confirm Booking
                    </button>
                  </form>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default TestsPage;
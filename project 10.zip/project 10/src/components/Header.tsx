import React, { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Heart, User, LogOut, Shield } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';

const Header: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();
  const { user, signOut } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminCheckLoading, setAdminCheckLoading] = useState(false);

  const navigation = [
    { name: 'AI Doctor Chatbot', path: '/chatbot' },
    { name: 'Find Doctors Nearby', path: '/doctors' },
    { name: 'Tests & Vaccinations', path: '/tests' },
    { name: 'Disease Map', path: '/disease-map' },
    { name: 'Health Feed', path: '/health-feed' },
    { name: 'Live Alerts', path: '/live-alerts' },
  ];

  useEffect(() => {
    if (user) {
      checkAdminStatus();
    } else {
      setIsAdmin(false);
    }
  }, [user]);

  const checkAdminStatus = async () => {
    if (!user) return;

    setAdminCheckLoading(true);
    try {
      const { data } = await supabase
        .from('admin_users')
        .select('id')
        .eq('id', user.id)
        .maybeSingle();

      setIsAdmin(!!data);
    } catch (error) {
      setIsAdmin(false);
    } finally {
      setAdminCheckLoading(false);
    }
  };

  const isActivePath = (path: string) => {
    return location.pathname === path;
  };

  const handleSignOut = async () => {
    try {
      setIsOpen(false); // Close mobile menu immediately
      await signOut();
    } catch (error) {
      console.error('Error signing out:', error);
      // Force redirect even if error occurs
      window.location.href = '/auth';
    }
  };

  // Don't show navigation if user is not logged in
  const showNavigation = user && location.pathname !== '/auth';
  return (
    <header className="bg-gradient-to-r from-orange-50/80 via-orange-100/60 to-orange-50/80 backdrop-blur-xl border-b border-orange-200/30 sticky top-0 z-50 shadow-lg shadow-orange-100/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link to={user ? "/chatbot" : "/"} className="flex items-center space-x-2">
            <img 
              src="/ellora_logo1.png" 
              alt="Ellora AI" 
              className="h-10 w-100"
            />
          </Link>

          {/* Desktop Navigation */}
          {showNavigation && (
            <nav className="hidden md:flex space-x-1 lg:space-x-2">
              {navigation.map((item) => (
                <Link
                  key={item.name}
                  to={item.path}
                  className={`px-2 lg:px-3 py-2 rounded-xl text-xs lg:text-sm font-medium transition-all duration-300 backdrop-blur-sm ${
                    isActivePath(item.path)
                      ? 'text-orange-700 bg-orange-200/50 shadow-md border border-orange-300/30'
                      : 'text-gray-700 hover:text-orange-600 hover:bg-orange-100/40 hover:shadow-sm'
                  }`}
                >
                  {item.name}
                </Link>
              ))}
            </nav>
          )}

          {/* Auth Section */}
          <div className="hidden md:flex items-center space-x-1 lg:space-x-2 xl:space-x-4">
            {user ? (
              <div className="flex items-center space-x-1 lg:space-x-2 xl:space-x-4">
                <span className="text-xs lg:text-sm text-gray-700 font-medium hidden lg:block truncate max-w-32 xl:max-w-none">Welcome, {user.email}</span>
                {isAdmin && !adminCheckLoading && (
                  <Link
                    to="/admin"
                    className={`flex items-center space-x-1 lg:space-x-2 px-2 lg:px-3 xl:px-4 py-2 rounded-xl font-medium transition-all duration-300 backdrop-blur-sm ${
                      isActivePath('/admin')
                        ? 'bg-purple-200/50 text-purple-700 border border-purple-300/30 shadow-md'
                        : 'text-purple-600 hover:text-purple-700 hover:bg-purple-100/40 hover:shadow-sm'
                    }`}
                  >
                    <Shield className="h-5 w-5" />
                    <span className="hidden lg:block">Admin</span>
                  </Link>
                )}
                <Link
                  to="/profile"
                  className="flex items-center space-x-1 lg:space-x-2 px-2 lg:px-3 py-2 rounded-xl text-gray-700 hover:text-orange-600 hover:bg-orange-100/40 transition-all duration-300 backdrop-blur-sm"
                >
                  <User className="h-5 w-5" />
                  <span className="hidden lg:block">Profile</span>
                </Link>
                <button
                  onClick={handleSignOut}
                  className="flex items-center space-x-1 lg:space-x-2 px-2 lg:px-3 py-2 rounded-xl text-gray-700 hover:text-red-600 hover:bg-red-100/40 transition-all duration-300 backdrop-blur-sm"
                >
                  <LogOut className="h-5 w-5" />
                  <span className="hidden lg:block">Sign Out</span>
                </button>
              </div>
            ) : (
              location.pathname !== '/auth' && (
                <Link
                  to="/auth"
                  className="bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-3 lg:px-6 py-2 rounded-xl font-medium transition-all duration-300 shadow-lg hover:shadow-xl backdrop-blur-sm text-sm lg:text-base"
                >
                  Sign In
                </Link>
              )
            )}
          </div>

          {/* Mobile menu button */}
          {showNavigation && (
            <button
              className="md:hidden p-2 rounded-lg hover:bg-orange-100/40 transition-colors duration-200"
              onClick={() => setIsOpen(!isOpen)}
            >
              {isOpen ? (
                <X className="h-6 w-6 text-gray-700" />
              ) : (
                <Menu className="h-6 w-6 text-gray-700" />
              )}
            </button>
          )}
        </div>
      </div>

      {/* Mobile Navigation */}
      {isOpen && showNavigation && (
        <div className="md:hidden backdrop-blur-xl">
          <div className="px-4 pt-2 pb-3 space-y-2 bg-gradient-to-b from-orange-50/90 to-orange-100/90 border-t border-orange-200/30 max-h-screen overflow-y-auto">
            {navigation.map((item) => (
              <Link
                key={item.name}
                to={item.path}
                className={`block px-4 py-3 rounded-xl font-medium transition-all duration-300 ${
                  isActivePath(item.path)
                    ? 'text-orange-700 bg-orange-200/50 shadow-md'
                    : 'text-gray-700 hover:text-orange-600 hover:bg-orange-100/40'
                }`}
                onClick={() => setIsOpen(false)}
              >
                {item.name}
              </Link>
            ))}
            
            {/* Mobile Auth Section */}
            {user ? (
              <div className="px-2 py-2 space-y-2 border-t border-orange-200/30 mt-2 pt-4">
                <div className="text-gray-700 font-medium px-4 py-2 truncate">Welcome, {user.email}</div>
                {isAdmin && !adminCheckLoading && (
                  <Link
                    to="/admin"
                    className={`flex items-center space-x-2 px-4 py-3 rounded-xl font-medium transition-all duration-300 ${
                      isActivePath('/admin')
                        ? 'text-purple-700 bg-purple-200/50 shadow-md'
                        : 'text-purple-600 hover:text-purple-700 hover:bg-purple-100/40'
                    }`}
                    onClick={() => setIsOpen(false)}
                  >
                    <Shield className="h-5 w-5" />
                    <span>Admin Panel</span>
                  </Link>
                )}
                <Link
                  to="/profile"
                  className="flex items-center space-x-2 px-4 py-3 rounded-xl text-gray-700 hover:text-orange-600 hover:bg-orange-100/40 font-medium transition-all duration-300"
                  onClick={() => setIsOpen(false)}
                >
                  <User className="h-5 w-5" />
                  <span>Profile</span>
                </Link>
                <button
                  onClick={handleSignOut}
                  className="flex items-center space-x-2 px-4 py-3 rounded-xl text-gray-700 hover:text-red-600 hover:bg-red-100/40 font-medium w-full text-left transition-all duration-300"
                >
                  <LogOut className="h-5 w-5" />
                  <span>Sign Out</span>
                </button>
              </div>
            ) : (
              <div className="px-2 py-2 border-t border-orange-200/30 mt-2 pt-4">
                <Link
                  to="/auth"
                  className="block bg-gradient-to-r from-orange-500 to-red-500 hover:from-orange-600 hover:to-red-600 text-white px-6 py-3 rounded-xl font-medium text-center transition-all duration-300 shadow-lg"
                  onClick={() => setIsOpen(false)}
                >
                  Sign In
                </Link>
              </div>
            )}
          </div>
        </div>
      )}
    </header>
  );
};

export default Header;
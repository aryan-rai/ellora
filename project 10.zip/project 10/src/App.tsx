import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import Header from './components/Header';
import AuthPage from './pages/AuthPage';
import ProfilePage from './pages/ProfilePage';
import ChatbotPage from './pages/ChatbotPage';
import DoctorsPage from './pages/DoctorsPage';
import DiseaseMapPage from './pages/DiseaseMapPage';
import HealthFeedPage from './pages/HealthFeedPage';
import LiveAlertsPage from './pages/LiveAlertsPage';
import AdminDashboard from './pages/AdminDashboard';
import HealthCardPage from './pages/HealthCardPage';
import TestsPage from './pages/TestsPage';
import ProtectedRoute from './components/ProtectedRoute';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="min-h-screen bg-gray-50">
          <Header />
          <main>
            <Routes>
              <Route path="/" element={<AuthPage />} />
              <Route path="/auth" element={<AuthPage />} />
              <Route path="/health-card/:userId" element={<HealthCardPage />} />
              <Route path="/chatbot" element={<ProtectedRoute><ChatbotPage /></ProtectedRoute>} />
              <Route path="/doctors" element={<ProtectedRoute><DoctorsPage /></ProtectedRoute>} />
              <Route path="/disease-map" element={<ProtectedRoute><DiseaseMapPage /></ProtectedRoute>} />
              <Route path="/health-feed" element={<ProtectedRoute><HealthFeedPage /></ProtectedRoute>} />
              <Route path="/live-alerts" element={<ProtectedRoute><LiveAlertsPage /></ProtectedRoute>} />
              <Route path="/profile" element={<ProtectedRoute><ProfilePage /></ProtectedRoute>} />
              <Route path="/tests" element={<ProtectedRoute><TestsPage /></ProtectedRoute>} />
              <Route path="/admin" element={<ProtectedRoute><AdminDashboard /></ProtectedRoute>} />
            </Routes>
          </main>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
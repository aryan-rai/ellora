/*
  # Fix Admin Users RLS Policy Infinite Recursion

  1. Policy Fix
    - Remove the recursive policy that causes infinite recursion
    - Replace with a simple policy that checks if the authenticated user's ID matches the admin_users.id
    - This avoids the circular dependency issue

  2. Security
    - Maintains proper access control
    - Only allows admins to see their own admin record
    - Prevents infinite recursion by using direct ID comparison
*/

-- Drop the problematic policy that causes infinite recursion
DROP POLICY IF EXISTS "Admins can manage admin users" ON admin_users;

-- Create a simple, non-recursive policy
CREATE POLICY "Users can read own admin record"
  ON admin_users
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

-- Create a policy for admins to manage other admin users (without recursion)
CREATE POLICY "Admins can manage admin users"
  ON admin_users
  FOR ALL
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);
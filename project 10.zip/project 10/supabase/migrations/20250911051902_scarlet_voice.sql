/*
  # Fix Health Card RLS Policies

  1. Security Changes
    - Update RLS policies to allow public read access for health cards
    - Maintain write restrictions for authenticated users only
    - Add policies for public health card viewing

  2. Tables Updated
    - user_profiles: Allow public read access
    - medical_conditions: Allow public read access  
    - medications: Allow public read access
    - allergies: Allow public read access
    - emergency_contacts: Allow public read access
*/

-- Update user_profiles policies for public health card access
DROP POLICY IF EXISTS "Public can read profiles for health cards" ON user_profiles;
CREATE POLICY "Public can read profiles for health cards"
  ON user_profiles
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Update medical_conditions policies for public health card access
DROP POLICY IF EXISTS "Public can read conditions for health cards" ON medical_conditions;
CREATE POLICY "Public can read conditions for health cards"
  ON medical_conditions
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Update medications policies for public health card access
DROP POLICY IF EXISTS "Public can read medications for health cards" ON medications;
CREATE POLICY "Public can read medications for health cards"
  ON medications
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Update allergies policies for public health card access
DROP POLICY IF EXISTS "Public can read allergies for health cards" ON allergies;
CREATE POLICY "Public can read allergies for health cards"
  ON allergies
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Update emergency_contacts policies for public health card access
DROP POLICY IF EXISTS "Public can read contacts for health cards" ON emergency_contacts;
CREATE POLICY "Public can read contacts for health cards"
  ON emergency_contacts
  FOR SELECT
  TO anon, authenticated
  USING (true);
/*
  # Add Admin Dashboard Tables

  1. New Tables
    - `admin_users` - Store admin user permissions
    - `health_articles` - Store health feed articles
    - `health_alerts` - Store live health alerts
  
  2. Security
    - Enable RLS on all tables
    - Add policies for admin-only access
    - Add policies for public read access to articles and alerts

  3. Functions
    - Function to check if user is admin
    - Triggers for automatic timestamps
*/

-- Create admin_users table
CREATE TABLE IF NOT EXISTS admin_users (
  id uuid PRIMARY KEY REFERENCES profiles(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'admin',
  permissions jsonb DEFAULT '{"manage_articles": true, "manage_alerts": true}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create health_articles table
CREATE TABLE IF NOT EXISTS health_articles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  summary text NOT NULL,
  content text NOT NULL,
  author text NOT NULL,
  publication text NOT NULL,
  category text NOT NULL,
  image_url text,
  source_url text,
  tags text[] DEFAULT '{}',
  is_breaking boolean DEFAULT false,
  is_published boolean DEFAULT true,
  created_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create health_alerts table
CREATE TABLE IF NOT EXISTS health_alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text NOT NULL,
  severity text NOT NULL CHECK (severity IN ('critical', 'high', 'medium', 'low', 'info')),
  category text NOT NULL,
  location text NOT NULL,
  affected_area text,
  estimated_impact text,
  source text NOT NULL,
  source_link text,
  is_active boolean DEFAULT true,
  created_by uuid REFERENCES profiles(id),
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Enable RLS
ALTER TABLE admin_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE health_articles ENABLE ROW LEVEL SECURITY;
ALTER TABLE health_alerts ENABLE ROW LEVEL SECURITY;

-- Admin users policies
CREATE POLICY "Admins can manage admin users"
  ON admin_users
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users au 
      WHERE au.id = auth.uid()
    )
  );

-- Health articles policies
CREATE POLICY "Anyone can read published articles"
  ON health_articles
  FOR SELECT
  TO authenticated, anon
  USING (is_published = true);

CREATE POLICY "Admins can manage articles"
  ON health_articles
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users au 
      WHERE au.id = auth.uid() 
      AND au.permissions->>'manage_articles' = 'true'
    )
  );

-- Health alerts policies
CREATE POLICY "Anyone can read active alerts"
  ON health_alerts
  FOR SELECT
  TO authenticated, anon
  USING (is_active = true);

CREATE POLICY "Admins can manage alerts"
  ON health_alerts
  FOR ALL
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM admin_users au 
      WHERE au.id = auth.uid() 
      AND au.permissions->>'manage_alerts' = 'true'
    )
  );

-- Create function to check if user is admin
CREATE OR REPLACE FUNCTION is_admin(user_id uuid)
RETURNS boolean
LANGUAGE plpgsql
SECURITY DEFINER
AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM admin_users 
    WHERE id = user_id
  );
END;
$$;

-- Add update triggers
CREATE TRIGGER update_admin_users_updated_at
  BEFORE UPDATE ON admin_users
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_health_articles_updated_at
  BEFORE UPDATE ON health_articles
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_health_alerts_updated_at
  BEFORE UPDATE ON health_alerts
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();
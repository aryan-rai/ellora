# Ellora AI - Modern Health Platform

A comprehensive health management platform with AI-powered features, real-time health alerts, and digital health cards.

## Features

- 🤖 **AI Doctor Chatbot** - Get instant medical advice and insights
- 🏥 **Find Doctors Nearby** - Locate healthcare providers with interactive maps
- 🗺️ **Disease Outbreak Map** - Real-time tracking of health incidents
- 📰 **Health News Feed** - Latest health articles and research
- 🚨 **Live Health Alerts** - Real-time health and safety notifications
- 💳 **Digital Health Cards** - Shareable medical profiles
- 👤 **Complete Health Profiles** - Manage medical records, conditions, medications, allergies
- 🛡️ **Admin Dashboard** - Content management for health articles and alerts

## Tech Stack

- **Frontend**: React 18 + TypeScript + Vite
- **Styling**: Tailwind CSS
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth
- **Maps**: React Leaflet
- **Icons**: Lucide React
- **Deployment**: Netlify Ready

## Quick Start

### Prerequisites
- Node.js 18+ 
- npm or yarn
- Supabase account

### Installation

1. **Clone the repository**
   ```bash
   git clone <your-repo-url>
   cd ellora-ai
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Set up environment variables**
   Create a `.env` file in the root directory:
   ```env
   VITE_SUPABASE_URL=your_supabase_project_url
   VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
   ```

4. **Set up Supabase database**
   - Create a new Supabase project
   - Run the migration files in the `supabase/migrations/` directory
   - Enable Row Level Security (RLS) on all tables

5. **Start development server**
   ```bash
   npm run dev
   ```

## Deployment to Netlify

### Method 1: Netlify CLI (Recommended)

1. **Install Netlify CLI**
   ```bash
   npm install -g netlify-cli
   ```

2. **Build the project**
   ```bash
   npm run build
   ```

3. **Deploy to Netlify**
   ```bash
   netlify deploy --prod --dir=dist
   ```

### Method 2: Git Integration

1. **Push your code to GitHub/GitLab**
   ```bash
   git add .
   git commit -m "Initial commit"
   git push origin main
   ```

2. **Connect to Netlify**
   - Go to [Netlify](https://netlify.com)
   - Click "New site from Git"
   - Connect your repository
   - Set build command: `npm run build`
   - Set publish directory: `dist`
   - Add environment variables in Netlify dashboard

### Method 3: Drag & Drop

1. **Build the project**
   ```bash
   npm run build
   ```

2. **Deploy manually**
   - Go to [Netlify](https://netlify.com)
   - Drag and drop the `dist` folder to Netlify

## Environment Variables

Add these environment variables in your Netlify dashboard:

```
VITE_SUPABASE_URL=your_supabase_project_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

## Database Setup

The application uses Supabase with the following main tables:
- `profiles` - User profiles
- `user_profiles` - Extended health profiles
- `medical_records` - Medical documents and records
- `medical_conditions` - Health conditions
- `medications` - Current medications
- `allergies` - Allergy information
- `emergency_contacts` - Emergency contact details
- `health_articles` - Health news articles
- `health_alerts` - Live health alerts
- `admin_users` - Admin user permissions

## Admin Access

To access the admin dashboard:

1. **Add admin user to database**
   ```sql
   INSERT INTO admin_users (id, role, permissions) 
   VALUES (
     'your_user_id', 
     'admin', 
     '{"manage_alerts": true, "manage_articles": true}'::jsonb
   );
   ```

2. **Access admin panel**
   - Navigate to `/admin` or click the Admin button in the header
   - Manage health articles and live alerts

## Features Overview

### For Users
- Complete health profile management
- AI-powered medical consultations
- Find nearby healthcare providers
- Track disease outbreaks in real-time
- Stay updated with health news
- Receive live health alerts
- Share digital health cards

### For Admins
- Manage health articles and news
- Create and manage live health alerts
- View user statistics and activity
- Content moderation and publishing

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, email support@ellora-ai.com or create an issue in the repository.